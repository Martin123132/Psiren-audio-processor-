# PGF Audio Suite - Quick Launch Script
# Run this if you've already built the project

if (!(Test-Path "pgf_app\pgf_engine.dll")) {
    Write-Host "DLL not found! Running build first..." -ForegroundColor Yellow
    & ".\build_and_run.ps1"
} else {
    Write-Host "Launching PGF Audio Suite..." -ForegroundColor Cyan
    python main.py
}
