import os
import subprocess
from setuptools import setup, Extension, find_packages
from setuptools.command.build_ext import build_ext

# CUDA configuration constant
CUDA_PATH = r'C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.0'

# --- Custom Build Step to run CMake ---
# This class tells setup.py to run CMake first.

class CMakeExtension(Extension):
    """A custom Extension to handle CMake."""
    def __init__(self, name, sourcedir=''):
        Extension.__init__(self, name, sources=[])
        self.sourcedir = os.path.abspath(sourcedir)

class CMakeBuild(build_ext):
    """Custom build_ext command to run CMake."""
    
    def run(self):
        # Try to find CMake in common locations
        cmake_paths = [
            'cmake',  # Try PATH first
            r'C:\Program Files\CMake\bin\cmake.exe',
            r'C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe'
        ]
        
        self.cmake_cmd = None
        for cmake_path in cmake_paths:
            try:
                subprocess.check_output([cmake_path, '--version'], stderr=subprocess.STDOUT)
                self.cmake_cmd = cmake_path
                print(f"Found CMake at: {cmake_path}")
                break
            except (OSError, subprocess.CalledProcessError):
                continue
        
        if not self.cmake_cmd:
            raise RuntimeError("CMake must be installed to build this project.")

        for ext in self.extensions:
            self.build_cmake(ext)
                
    def build_cmake(self, ext):
        build_temp = os.path.join(self.build_temp, "cmake")
        if not os.path.exists(build_temp):
            os.makedirs(build_temp)
            
        # The output directory for the final .dll/.so
        extdir = os.path.abspath(os.path.dirname(self.get_ext_fullpath(ext.name)))
        extdir = os.path.join(extdir, "pgf_app") # Put it inside the package
        
        cmake_args = [
            f'-DCMAKE_LIBRARY_OUTPUT_DIRECTORY={extdir}',
            '-DCMAKE_BUILD_TYPE=Release',
            '-DCUDAToolkit_ROOT=C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.0',
            '-DBUILD_PLUGIN=OFF',  # Don't build plugin during Python setup
            '-G', 'Visual Studio 17 2022',
            '-A', 'x64',
            '-T', 'cuda=13.0',
            f'-DCMAKE_CUDA_COMPILER={CUDA_PATH}/bin/nvcc.exe'.replace('\\', '/')
        ]
        
        build_args = ['--config', 'Release']
        
        # Set environment variables for CUDA and MSBuild CUDA targets
        env = os.environ.copy()
        env['CUDA_PATH'] = CUDA_PATH
        env['CUDAToolkit_ROOT'] = CUDA_PATH
        env['CudaToolkitDir'] = CUDA_PATH

        # Try with CUDA first
        try:
            print("Attempting build with CUDA support...")
            subprocess.check_call([self.cmake_cmd, ext.sourcedir] + cmake_args, cwd=build_temp, env=env)
            subprocess.check_call([self.cmake_cmd, '--build', '.'] + build_args, cwd=build_temp, env=env)
            print(f"PGF C++ Engine built with CUDA and copied to {extdir}")
        except subprocess.CalledProcessError:
            print("\n" + "="*60)
            print("CUDA build failed. Retrying with CPU-only mode...")
            print("="*60 + "\n")
            
            # Clean and retry without CUDA
            import shutil
            shutil.rmtree(build_temp, ignore_errors=True)
            os.makedirs(build_temp)
            
            cmake_args_no_cuda = [
                f'-DCMAKE_LIBRARY_OUTPUT_DIRECTORY={extdir}',
                '-DCMAKE_BUILD_TYPE=Release',
                '-DUSE_CUDA=OFF',
                '-DBUILD_PLUGIN=OFF',
                '-G', 'Visual Studio 17 2022',
                '-A', 'x64'
            ]
            
            subprocess.check_call([self.cmake_cmd, ext.sourcedir] + cmake_args_no_cuda, cwd=build_temp)
            subprocess.check_call([self.cmake_cmd, '--build', '.'] + build_args, cwd=build_temp)
            print(f"PGF C++ Engine built (CPU-only) and copied to {extdir}")

# --- Main setup() function ---
setup(
    name="PGF_Audio_Suite",
    version="1.0.0",
    author="Glyn",
    description="PGF Audio Suite (Live, Studio, Warmth)",
    
    # Find all Python packages (pgf_app, pgf_app.core, etc.)
    packages=find_packages(),
    
    # Tell setup.py to use our custom CMake builder
    ext_modules=[CMakeExtension('pgf_engine', sourcedir='.')],
    cmdclass={'build_ext': CMakeBuild},
    
    # Define dependencies (from requirements.txt)
    install_requires=[
        'numpy',
        'PyQt5',
        'sounddevice',
        'soundfile'
    ],
    
    # This ensures that the .dll/.so is included in the final package
    include_package_data=True,
    package_data={
        'pgf_app': ['pgf_engine.dll', 'libpgf_engine.so'],
    },
    
    zip_safe=False,
    
    # Define the main entry point
    entry_points={
        'gui_scripts': [
            'pgf_audio = main:main',
        ]
    }
)