# PGF Audio Suite - Build and Run Script
# This script builds the C++ engine and runs the Python application

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "PGF Audio Suite - Build Script" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

# Step 1: Build the C++ engine using setup.py
Write-Host "`n[1/3] Building C++ Engine (CPU-only mode)..." -ForegroundColor Yellow
python setup.py build_ext --inplace

if ($LASTEXITCODE -ne 0) {
    Write-Host "`nBuild failed! Check the error messages above." -ForegroundColor Red
    exit 1
}

Write-Host "`n[2/3] Copying DLL to application directory..." -ForegroundColor Yellow
$dllPath = Get-ChildItem -Path "build" -Filter "pgf_engine.dll" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1

if ($dllPath) {
    Copy-Item $dllPath.FullName "pgf_app\pgf_engine.dll" -Force
    Write-Host "✓ pgf_engine.dll copied successfully!" -ForegroundColor Green
} else {
    Write-Host "✗ Could not find pgf_engine.dll. Build may have failed." -ForegroundColor Red
    exit 1
}

Write-Host "`n[3/3] Launching Application..." -ForegroundColor Yellow
Write-Host "========================================`n" -ForegroundColor Cyan

python main.py