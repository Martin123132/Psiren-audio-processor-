# PGF Audio Suite - Build Everything Script
# Builds: 1) C++ Engine DLL, 2) VST3 Plugin

param(
    [switch]$NoCUDA,
    [switch]$NoPlugin,
    [switch]$Clean
)

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "PGF Audio Suite - Full Build Script" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

# Clean build directory if requested
if ($Clean) {
    Write-Host "`nCleaning build directory..." -ForegroundColor Yellow
    Remove-Item -Path "build" -Recurse -Force -ErrorAction SilentlyContinue
}

# Prepare CMake arguments
$cmakeArgs = @()
if ($NoCUDA) {
    Write-Host "`nCUDA disabled by user" -ForegroundColor Yellow
    $cmakeArgs += "-DUSE_CUDA=OFF"
} else {
    Write-Host "`nAttempting to build with CUDA support..." -ForegroundColor Yellow
}

if ($NoPlugin) {
    Write-Host "Plugin build disabled by user" -ForegroundColor Yellow
    $cmakeArgs += "-DBUILD_PLUGIN=OFF"
}

# Step 1: Build using setup.py (builds the Python DLL)
Write-Host "`n[1/3] Building C++ Engine for Python..." -ForegroundColor Cyan
$env:CUDA_PATH = "C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.0"

try {
    python setup.py build_ext --inplace
    if ($LASTEXITCODE -ne 0) {
        throw "Build failed"
    }
} catch {
    Write-Host "`nEngine build failed! Trying without CUDA..." -ForegroundColor Red
    
    # Retry without CUDA
    if (-not $NoCUDA) {
        Write-Host "Retrying with -DUSE_CUDA=OFF..." -ForegroundColor Yellow
        $env:CMAKE_ARGS = "-DUSE_CUDA=OFF"
        python setup.py build_ext --inplace
        if ($LASTEXITCODE -ne 0) {
            Write-Host "`nBuild failed even without CUDA!" -ForegroundColor Red
            exit 1
        }
    } else {
        exit 1
    }
}

# Step 2: Copy DLL
Write-Host "`n[2/3] Copying engine DLL..." -ForegroundColor Cyan
$dllPath = Get-ChildItem -Path "build" -Filter "pgf_engine.dll" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1

if ($dllPath) {
    Copy-Item $dllPath.FullName "pgf_app\pgf_engine.dll" -Force
    Write-Host "✓ pgf_engine.dll copied to pgf_app\" -ForegroundColor Green
} else {
    Write-Host "✗ Could not find pgf_engine.dll" -ForegroundColor Red
    exit 1
}

# Step 3: Build plugin (optional)
if (-not $NoPlugin) {
    Write-Host "`n[3/3] Building VST3 Plugin..." -ForegroundColor Cyan
    
    # Find CMake
    $cmake = "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe"
    if (-not (Test-Path $cmake)) {
        Write-Host "CMake not found, skipping plugin build" -ForegroundColor Yellow
    } else {
        # Check if plugin build directory exists
        if (-not (Test-Path "build\plugin")) {
            New-Item -ItemType Directory -Path "build\plugin" -Force | Out-Null
        }
        
        Push-Location "build\plugin"
        
        try {
            & $cmake ../.. -G "Visual Studio 17 2022" -A x64 @cmakeArgs
            & $cmake --build . --config Release --target PGF_Warmth
            
            if ($LASTEXITCODE -eq 0) {
                Write-Host "✓ Plugin built successfully!" -ForegroundColor Green
                
                # Find the VST3
                $vst3 = Get-ChildItem -Recurse -Filter "PGF Warmth.vst3" -Directory | Select-Object -First 1
                if ($vst3) {
                    Write-Host "Plugin location: $($vst3.FullName)" -ForegroundColor Cyan
                }
            } else {
                Write-Host "Plugin build encountered errors" -ForegroundColor Yellow
            }
        } catch {
            Write-Host "Plugin build failed: $_" -ForegroundColor Yellow
        } finally {
            Pop-Location
        }
    }
} else {
    Write-Host "`n[3/3] Plugin build skipped" -ForegroundColor Yellow
}

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "Build Complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "`nTo run the app: python main.py" -ForegroundColor White
Write-Host "To test CUDA: Check the console output when processing audio`n" -ForegroundColor White
