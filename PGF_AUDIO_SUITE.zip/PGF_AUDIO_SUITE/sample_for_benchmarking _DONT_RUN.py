import os
import tempfile
import shutil
import tarfile
import requests
import time
import zlib
import bz2
import lzma
import zstandard
import brotli
import lz4.frame
import io
import matplotlib.pyplot as plt
import numpy as np
import hashlib # Import hashlib for the updated gmw_tool functions
import struct # Import struct for the updated gmw_tool functions
import json # Import json for the updated gmw_tool functions
from dataclasses import dataclass # Import dataclass for the updated gmw_tool functions
from pathlib import Path # Import Path for the updated gmw_tool functions
from typing import List, Tuple, Optional, Iterable, Dict # Import typing hints
from concurrent.futures import ThreadPoolExecutor, as_completed # Import for ThreadPoolExecutor
import random # Import random for synthetic data generation functions
import string # Import string for synthetic data generation functions
import wave # Import wave for synthetic data generation functions
import pandas as pd # Import pandas for synthetic data generation functions
from PIL import Image # Import PIL for synthetic data generation functions
from tqdm import tqdm # Import tqdm for progress bar

# --- gmw_tool.py code (modified) ---

try:
 import zstandard as zstd # optional
 HAS_ZSTD = True
except Exception:
 zstd = None
 HAS_ZSTD = False

try:
 from cryptography.hazmat.primitives.ciphers.aead import AESGCM # optional
 HAS_AESGCM = True
except Exception:
 AESGCM = None
 HAS_AESGCM = False

try:
 import xxhash
 HAS_XX = True
except Exception:
 xxhash = None
 HAS_XX = False

# -----------------------------------------------------------------------------
# Morton encoding helpers for voxel keys

_DILATE16 = [0] * 65536

def _init_dilate():
 for i in range(65536):
  n = i
  n = (n | (n << 16)) & 0x0000FFFF0000FFFF
  n = (n | (n << 8)) & 0x00FF00FF00FF00FF
  n = (n | (n << 4)) & 0x0F0F0F0F0F0F0F0F
  n = (n | (n << 2)) & 0x3333333333333333
  n = (n | (n << 1)) & 0x5555555555555555
  _DILATE16[i] = n

# Ensure dilate is initialized
if _DILATE16[1] == 0: # Check if it's still the initial state
 _init_dilate()


def morton64(x: int, y: int, z: int) -> int:
 x &= 0x1FFFFF
 y &= 0x1FFFFF
 z &= 0x1FFFFF
 xx = _DILATE16[x & 0xFFFF] | (_DILATE16[(x >> 16) & 0xFFFF] << 32)
 yy = _DILATE16[y & 0xFFFF] | (_DILATE16[(y >> 16) & 0xFFFF] << 32)
 zz = _DILATE16[z & 0xFFFF] | (_DILATE16[(z >> 16) & 0xFFFF] << 32)
 return (xx | (yy << 1) | (zz << 2)) & ((1 << 64) - 1)



# Varint helpers

def enc_varint(n: int) -> bytes:
 out = bytearray()
 while True:
  b = n & 0x7F
  n >>= 7
  if n:
   out.append(0x80 | b)
  else:
   out.append(b)
   break
 return bytes(out)

def dec_varint(buf: bytes, off: int) -> Tuple[int, int]:
 shift = 0
 val = 0
 while True:
 b = buf[off]
 off += 1
 val |= (b & 0x7F) << shift
 if not (b & 0x80):
 break
 shift += 7
 return val, off

# Bloom filter hash (deterministic)

def _bloom_hash(key: int, i: int) -> int:
 x = (key + 0x9E3779B97F4A7C15 + i) & 0xFFFFFFFFFFFFFFFF
 x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9 & 0xFFFFFFFFFFFFFFFF
 x = (x ^ (x >> 27)) * 0x94D049BB133111EB & 0xFFFFFFFFFFFFFFFF
 x = x ^ (x >> 31)
 return x & 0xFFFFFFFF

def _bloom_add(bits: bytearray, key: int, m: int, h: int = 3) -> None:
 for i in range(h):
 hv = _bloom_hash(key, i) % m
 bits[hv // 8] |= 1 << (hv % 8)


# Format constants

MAGIC = b"MBT2\0"
VERSION = 2

FLAG_ZLIB = 1 << 0
FLAG_ZSTD = 1 << 1
FLAG_AESGCM = 1 << 2
FLAG_VARINT = 1 << 3
FLAG_COLUMN = 1 << 4
FLAG_HILBERT = 1 << 5
FLAG_KEY_128 = 1 << 6

HEADER = struct.Struct("<5sB I H I Q")
ENTRY = struct.Struct("<Q I Q I Q 32s H I") # Added stats_off field (currently unused)
FOOTER = struct.Struct("<I 32s 32s I")

@dataclass
class WriterCfg:
 """Recommended configuration for writing MBT2 archives."""
 target_bucket_kb: int = 128
 use_zstd: bool = True
 zstd_level: int = 3
 threads: int = max(1, os.cpu_count() or 1)
 aesgcm_key: Optional[bytes] = None
 sha256_each: bool = False
 bloom_bits: int = 2048
 column_layout: bool = True

@dataclass
class MBT2Record:
 """Represents a single MBT2 record with physics components."""
 key: int # Morton key (space)
 mass: float # Motion (resistance)
 entropy: float # Entropy (time)
 tau: float # Curvature memory (time-space)


def _compress(raw: bytes, zstd_on: bool, lvl: int = 3) -> bytes:
 if zstd_on and HAS_ZSTD:
 return zstd.ZstdCompressor(level=lvl).compress(raw)
 return zlib.compress(raw, 6)


def _maybe_encrypt(aes_key: Optional[bytes], data: bytes, aad: bytes) -> bytes:
 if not aes_key or not HAS_AESGCM:
 return data
 nonce = os.urandom(12)
 return nonce + AESGCM(aes_key).encrypt(nonce, data, aad)

def _xx64(b: bytes) -> int:
 if HAS_XX:
 return xxhash.xxh64(b).intdigest()
 # Fallback using blake2b if xxhash is not available
 return int.from_bytes(hashlib.blake2b(b, digest_size=8).digest(), "little")


def _autotune_bucket_kb(n: int, approx_rec_bytes: int = 20) -> int:
 recs = max(4096, min(12288, n // 80))
 kb = max(64, min(256, (recs * approx_rec_bytes) // 1024))
 return int(kb)

def _pack_bucket(records: List[MBT2Record], column: bool = True) -> bytes:
 n = len(records)
 if n == 0:
 return b""
 out = bytearray()
 out += struct.pack("<Q", records[0].key)
 prev = records[0].key
 for i in range(1, n):
 d = records[i].key - prev
 out += enc_varint(d)
 prev = records[i].key
 if column:
 out += struct.pack(f"<{n}f", *[r.mass for r in records])
 out += struct.pack(f"<{n}f", *[r.entropy for r in records])
 out += struct.pack(f"<{n}f", *[r.tau for r in records])
 else:
 for r in records:
 out += struct.pack("<fff", r.mass, r.entropy, r.tau)
 return bytes(out)

def _build_buckets(sorted_recs: List[MBT2Record], target_kb: int) -> List[List[MBT2Record]]:
 target = target_kb * 1024
 out: List[List[MBT2Record]] = []
 current_bucket: List[MBT2Record] = []
 size = 0
 for rec in sorted_recs:
 # Estimate size: 8 bytes for first key + varint diffs (avg ~3 bytes) + 12 bytes for 3 floats
 add = (3 if current_bucket else 8) + 12
 if size + add > target and current_bucket:
 out.append(current_bucket)
 current_bucket = []
 size = 0
 current_bucket.append(rec)
 size += add
 if current_bucket:
 out.append(current_bucket)
 return out


def write_mbt2(path: Path, records: List[MBT2Record], cfg: WriterCfg = WriterCfg()) -> Dict:
 path = Path(path)
 t_sort0 = time.perf_counter()
 records.sort(key=lambda r: r.key)
 t_sort = time.perf_counter() - t_sort0
 # Autotune only if target_bucket_kb is not set (<= 0)
 if cfg.target_bucket_kb <= 0:
 cfg.target_bucket_kb = _autotune_bucket_kb(len(records))
 buckets = _build_buckets(records, cfg.target_bucket_kb)
 nb = len(buckets)
 flags = 0
 flags |= FLAG_ZSTD if (cfg.use_zstd and HAS_ZSTD) else FLAG_ZLIB
 flags |= FLAG_VARINT
 if cfg.column_layout:
 flags |= FLAG_COLUMN
 if cfg.aesgcm_key and HAS_AESGCM:
 flags |= FLAG_AESGCM
 with open(path, "w+b") as f:
 f.write(HEADER.pack(MAGIC, VERSION, flags, cfg.target_bucket_kb, nb, 0))
 header_end = f.tell()
 bloom_bytes = cfg.bloom_bits // 8
 entry_size = ENTRY.size + bloom_bytes
 table_ofs = header_end
 f.seek(table_ofs + nb * entry_size)
 metas = []
 lock = threading.Lock()
 def write_bucket(i: int, b: List[MBT2Record]) -> None:
 raw = _pack_bucket(b, column=bool(flags & FLAG_COLUMN))
 comp = _compress(raw, zstd_on=bool(flags & FLAG_ZSTD), lvl=cfg.zstd_level)
 comp = _maybe_encrypt(cfg.aesgcm_key if (flags & FLAG_AESGCM) else None, comp, aad=struct.pack("<I", i))
 xx = _xx64(comp)
 sh = hashlib.sha256(comp).digest() if cfg.sha256_each else b"\x00" * 32
 bloom = bytearray(bloom_bytes)
 for rec in b:
 _bloom_add(bloom, rec.key, cfg.bloom_bits)
 with lock:
 pos = f.tell()
 f.write(comp)
 metas.append((b[0].key, len(b), pos, len(comp), xx, sh, bytes(bloom)))
 t_comp0 = time.perf_counter()
 with ThreadPoolExecutor(max_workers=cfg.threads) as ex:
 futs = [ex.submit(write_bucket, i, b) for i, b in enumerate(buckets)]
 for fu in as_completed(futs):
 fu.result()
 t_comp = time.perf_counter() - t_comp0
 metas.sort(key=lambda m: m[0])
 data_end = f.tell()
 f.seek(table_ofs)
 for (start, count, off, length, xx, sh, bloom) in metas:
 f.write(ENTRY.pack(start, count, off, length, xx, sh, len(bloom), 0))
 f.write(bloom)
 f.seek(table_ofs)
 table_blob = f.read(nb * entry_size)
 table_hash = hashlib.sha256(table_blob).digest()
 leaves = [sh if cfg.sha256_each else xx.to_bytes(8, "little") for (_, _, _, _, xx, sh, _) in metas]
 if leaves:
 cur = [hashlib.sha256(x).digest() if len(x) != 32 else x for x in leaves]
 while len(cur) > 1:
 nxt = []
 for i in range(0, len(cur), 2):
 a = cur[i]
 b = cur[i + 1] if i + 1 < len(cur) else a
 nxt.append(hashlib.sha256(a + b).digest())
 cur = nxt
 merkle = cur[0]
 else:
 merkle = b"\x00" * 32
 f.seek(data_end)
 feature_crc = zlib.crc32(struct.pack("<IHH", VERSION, cfg.target_bucket_kb, flags)) & 0xFFFFFFFF
 f.write(FOOTER.pack(nb * entry_size, table_hash, merkle, feature_crc))
 end_pos = f.tell()
 f.seek(0)
 f.write(HEADER.pack(MAGIC, VERSION, flags, cfg.target_bucket_kb, nb, table_ofs))
 f.seek(end_pos)
 manifest = {
 "nbuckets": nb,
 "schema": 0,
 "flags": flags,
 "target_bucket_kb": cfg.target_bucket_kb,
 "compressor": "zstd" if (flags & FLAG_ZSTD) else "zlib",
 "aesgcm": bool(flags & FLAG_AESGCM),
 "column": bool(flags & FLAG_COLUMN),
 "varint": bool(flags & FLAG_VARINT),
 "bloom_bits": cfg.bloom_bits,
 }
 man_bytes = json.dumps(manifest, separators=(",", ":")).encode("utf-8")
 f.write(man_bytes)
 f.write(struct.pack("<I", len(man_bytes)))
 return {
 "file_mb": os.path.getsize(path) / (1024 * 1024),
 "nbuckets": nb,
 "bucket_kb": cfg.target_bucket_kb,
 "flags": flags,
 }


# -----------------------------------------------------------------------------
# Generic .gmw archive helpers

def compress_folder_to_gmw(folder_path: str, output_path: str, use_zstd: bool = True, zstd_level: int = 3) -> None:
 folder = Path(folder_path)
 output = Path(output_path)
 assert folder.is_dir(), f"{folder_path} is not a directory"

 buf = io.BytesIO()
 # Estimate the number of files for tqdm progress bar
 file_count = sum(len(files) for _, _, files in os.walk(folder))

 with tarfile.open(fileobj=buf, mode="w") as tf:
 with tqdm(total=file_count, unit='file', desc=f'Compressing {folder.name}') as pbar:
 for root, _, files in os.walk(folder):
 for file in files:
 file_path = Path(root) / file
 tf.add(file_path, arcname=file_path.relative_to(folder))
 pbar.update(1)

 tar_data = buf.getvalue()

 if use_zstd and HAS_ZSTD:
 comp = zstd.ZstdCompressor(level=zstd_level).compress(tar_data)
 compressor_name = "zstd"
 else:
 comp = zlib.compress(tar_data, 6)
 compressor_name = "zlib"

 # Calculate checksum of compressed data
 checksum = hashlib.sha256(comp).hexdigest()

 # Create metadata dictionary
 metadata = {
 "compressor": compressor_name,
 "zstd_level": zstd_level if compressor_name == "zstd" else None,
 "checksum": checksum,
 "checksum_algorithm": "sha256"
 }

 # Serialize metadata to JSON and encode
 metadata_bytes = json.dumps(metadata, separators=(",", ":")).encode("utf-8")
 metadata_length = struct.pack("<I", len(metadata_bytes))

 # Write compressed data, metadata, and metadata length to the output file
 with open(output, "wb") as out_f:
 out_f.write(comp)
 out_f.write(metadata_bytes)
 out_f.write(metadata_length)


def extract_gmw(gmw_path: str, output_dir: str) -> None:
 gmw_file = Path(gmw_path)
 out_dir = Path(output_dir)
 out_dir.mkdir(parents=True, exist_ok=True)

 with open(gmw_file, "rb") as in_f:
 # Read metadata length from the end of the file
 in_f.seek(-4, os.SEEK_END)
 metadata_length = struct.unpack("<I", in_f.read(4))[0]

 # Read metadata
 in_f.seek(-4 - metadata_length, os.SEEK_END)
 metadata_bytes = in_f.read(metadata_length)
 metadata = json.loads(metadata_bytes)

 # Get compressor information and expected checksum
 compressor_name = metadata.get("compressor")
 expected_checksum = metadata.get("checksum")
 checksum_algorithm = metadata.get("checksum_algorithm", "sha256") # Default to sha256

 # Read compressed data (excluding metadata and its length)
 in_f.seek(0)
 comp_data = in_f.read(os.path.getsize(gmw_file) - metadata_length - 4)

 # Verify checksum of the compressed data
 if checksum_algorithm == "sha256":
 actual_checksum = hashlib.sha256(comp_data).hexdigest()
 elif checksum_algorithm == "xxhash64" and HAS_XX:
 actual_checksum = xxhash.xxh64(comp_data).hexdigest()
 else:
 raise ValueError(f"Unsupported or unavailable checksum algorithm: {checksum_algorithm}")


 if actual_checksum != expected_checksum:
 raise ValueError(f"Checksum mismatch! Expected: {expected_checksum}, Got: {actual_checksum}")

 # Decompress data based on metadata
 if compressor_name == "zstd" and HAS_ZSTD:
 tar_data = zstd.ZstdDecompressor().decompress(comp_data)
 elif compressor_name == "zlib":
 tar_data = zlib.decompress(comp_data)
 else:
 raise ValueError(f"Unsupported or unavailable compressor: {compressor_name}")

 # Extract tar data with progress bar
 with io.BytesIO(tar_data) as buf:
 with tarfile.open(fileobj=buf, mode="r") as tf:
 total_members = len(tf.getmembers())
 # Check if total_members is reasonable before creating tqdm
 if total_members > 0:
 with tqdm(total=total_members, unit='file', desc=f'Extracting to {out_dir.name}') as pbar:
 for member in tf.getmembers():
 tf.extract(member, path=out_dir)
 pbar.update(1)
 else:
 # If no members, just extract all (handles empty archives or unexpected structures)
 tf.extractall(path=out_dir)
 print(f"Extracted archive '{gmw_path}' to '{out_dir}' (no distinct files/members found).")


# --- Benchmarking Code ---

# Define dataset information
dataset_info = {
 'text': {
 'name': 'Tiny Shakespeare',
 'description': 'A small text corpus of Shakespeare\'s plays.',
 'source': 'Andrej Karpathy\'s repo',
 'url': 'https://raw.githubusercontent.com/karpathy/char-rnn/master/data/tinyshakespeare/input.txt',
 'approx_size': '1 MB'
 },
 'image': {
 'name': 'CIFAR-10 (Subset)',
 'description': 'A subset of the CIFAR-10 dataset containing 10 classes of 32x32 color images.',
 'source': 'Kaggle or official website',
 'url': 'https://www.cs.toronto.edu/~kriz/cifar-10-python.tar.gz',
 'approx_size': '170 MB (full dataset), we will use a subset'
 },
 'audio': {
 'name': 'Speech Commands Dataset (Subset)',
 'description': 'A subset of the Speech Commands dataset, containing short audio clips of spoken words.',
 'source': 'TensorFlow Datasets or Kaggle',
 'url': 'http://download.tensorflow.org/data/speech_commands_v0.02.tar.gz',
 'approx_size': '2.4 GB (full dataset), we will use a subset'
 },
 'structured': {
 'name': 'UCI Adult Income Dataset',
 'description': 'Contains demographic data from the 1994 Census Bureau database, used for predicting income.',
 'source': 'UCI Machine Learning Repository',
 'url': 'https://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.data',
 'approx_size': '4 MB'
 }
}

# Create a directory to store the downloaded datasets
dataset_dir = 'real_world_datasets'
os.makedirs(dataset_dir, exist_ok=True)

# Download the datasets
print("--- Downloading Datasets ---")
for data_type, info in dataset_info.items():
 url = info['url']
 file_name = url.split('/')[-1]
 file_path = os.path.join(dataset_dir, file_name)

 if not os.path.exists(file_path):
 print(f"Downloading {info['name']}...")
 try:
 response = requests.get(url, stream=True)
 response.raise_for_status() # Raise an exception for bad status codes
 with open(file_path, 'wb') as f:
 for chunk in response.iter_content(chunk_size=8192):
 f.write(chunk)
 print(f"Downloaded {info['name']} to {file_path}")
 except requests.exceptions.RequestException as e:
 print(f"Error downloading {info['name']}: {e}")
 # Remove the incomplete file if download failed
 if os.path.exists(file_path):
 os.remove(file_path)
 else:
 print(f"{info['name']} already exists at {file_path}")

# Prepare datasets for compression
print("\n--- Preparing Datasets ---")
temp_dataset_dir = tempfile.mkdtemp()
print(f"Created temporary directory for datasets: {temp_dataset_dir}")

prepared_dataset_paths = {}

for data_type, info in dataset_info.items():
 file_name = info['url'].split('/')[-1]
 downloaded_file_path = os.path.join(dataset_dir, file_name)

 if os.path.exists(downloaded_file_path):
 dataset_subdir = os.path.join(temp_dataset_dir, data_type)
 os.makedirs(dataset_subdir, exist_ok=True)
 print(f"Created subdirectory: {dataset_subdir}")

 if file_name.endswith('.tar.gz'):
 print(f"Extracting {file_name}...")
 try:
 with tarfile.open(downloaded_file_path, 'r:gz') as tar:
 # Using filter='data' to mitigate CVE-2007-4559
 tar.extractall(path=dataset_subdir, filter='data')
 print(f"Extracted {file_name} to {dataset_subdir}")

 # For large archives like CIFAR-10 and Speech Commands, select a subset
 if data_type in ['image', 'audio']:
 print(f"Selecting a subset for {data_type} data...")
 extracted_items = [os.path.join(dataset_subdir, item) for item in os.listdir(dataset_subdir)]
 extracted_files = [item for item in extracted_items if os.path.isfile(item)]
 extracted_dirs = [item for item in extracted_items if os.path.isdir(item)]

 items_to_keep = []
 if data_type == 'image':
 data_file = next((f for f in extracted_files if 'data_batch' in f or 'test_batch' in f), None)
 if data_file:
 items_to_keep.append(data_file)
 else:
 cifar_dirs = [d for d in extracted_dirs if 'cifar-10-batches-py' in d]
 if cifar_dirs:
 items_to_keep.append(cifar_dirs[0])
 else:
 items_to_keep.extend(extracted_files[:5]) # Fallback

 elif data_type == 'audio':
 word_dirs = [d for d in extracted_dirs if os.path.basename(d) not in ['_background_noise_', 'LICENSE', 'README.md']]
 items_to_keep.extend(word_dirs[:3]) # Keep first 3 word directories

 for item in extracted_items:
 if item not in items_to_keep:
 if os.path.isdir(item):
 shutil.rmtree(item)
 else:
 os.remove(item)
 print(f"Subset selected for {data_type}. Remaining items: {[os.path.basename(item) for item in items_to_keep]}")

 except tarfile.ReadError as e:
 print(f"Error extracting {file_name}: {e}. This might not be a valid tar.gz file.")
 if os.path.exists(dataset_subdir):
 shutil.rmtree(dataset_subdir)
 continue
 except Exception as e:
 print(f"An unexpected error occurred during extraction of {file_name}: {e}")
 if os.path.exists(dataset_subdir):
 shutil.rmtree(dataset_subdir)
 continue
 else:
 shutil.copy(downloaded_file_path, dataset_subdir)
 print(f"Copied {file_name} to {dataset_subdir}")
 else:
 print(f"Downloaded file not found for {data_type} at {downloaded_file_path}")


# Store the paths to the prepared dataset directories
prepared_dataset_paths = {}
for data_type in dataset_info.keys():
 dataset_subdir = os.path.join(temp_dataset_dir, data_type)
 if os.path.exists(dataset_subdir) and os.listdir(dataset_subdir):
 prepared_dataset_paths[data_type] = dataset_subdir
 else:
 print(f"Warning: No prepared data found for {data_type} in {dataset_subdir}")

print("\n--- Prepared Dataset Paths ---")
print(prepared_dataset_paths)


# Benchmark compression with wider variations
print("\n--- Running Benchmarks ---")
benchmark_results_comprehensive = {}
zstd_levels = [1, 3, 6, 9] # Wider range of ZSTD compression levels to test

for data_type, dataset_path in prepared_dataset_paths.items():
 print(f"\nBenchmarking real-world {data_type} data from {dataset_path}")

 original_size = sum(os.path.getsize(os.path.join(root, name)) for root, dirs, files in os.walk(dataset_path) for name in files)

 benchmark_results_comprehensive[data_type] = {'original_size': original_size}

 # Benchmark GMW compression with different ZSTD levels
 for level in zstd_levels:
 gmw_output_path = f"{dataset_path}.gmw_zstd{level}"
 gmw_start_time = time.time()
 # For GMW, create a temporary directory with the single file to be compressed
 temp_gmw_dir = tempfile.mkdtemp()
 # Copy contents of dataset_path to temp_gmw_dir
 for item in os.listdir(dataset_path):
 s = os.path.join(dataset_path, item)
 d = os.path.join(temp_gmw_dir, item)
 if os.path.isdir(s):
 shutil.copytree(s, d)
 else:
 shutil.copy2(s, d)

 compress_folder_to_gmw(temp_gmw_dir, gmw_output_path, use_zstd=True, zstd_level=level)
 gmw_end_time = time.time()
 gmw_compression_time = gmw_end_time - gmw_start_time
 gmw_compressed_size = os.path.getsize(gmw_output_path)
 shutil.rmtree(temp_gmw_dir) # Clean up temporary directory

 benchmark_results_comprehensive[data_type][f'gmw_zstd_{level}'] = {
 'compressed_size': gmw_compressed_size,
 'compression_time': gmw_compression_time
 }
 print(f" GMW (ZSTD level {level}) compressed size: {gmw_compressed_size} bytes")
 print(f" GMW (ZSTD level {level}) compression time: {gmw_compression_time:.4f} seconds")


 # Prepare data for pure compression methods (read into memory/buffer)
 data_to_compress_pure = b''
 for root, _, files in os.walk(dataset_path):
 for file in files:
 with open(os.path.join(root, file), 'rb') as f:
 data_to_compress_pure += f.read()


 # Benchmark standard compression (tar.gz)
 standard_gz_output_path = f"{dataset_path}.tar.gz"
 standard_gz_start_time = time.time()
 with open(standard_gz_output_path, 'wb') as out_f:
 with tarfile.open(fileobj=out_f, mode='w:gz') as tf:
 tf.add(dataset_path, arcname='.')
 standard_gz_end_time = time.time()
 standard_gz_compression_time = standard_gz_end_time - standard_gz_start_time
 standard_gz_compressed_size = os.path.getsize(standard_gz_output_path)

 benchmark_results_comprehensive[data_type]['standard_tar_gz'] = {
 'compressed_size': standard_gz_compressed_size,
 'compression_time': standard_gz_compression_time
 }
 print(f" Standard (tar.gz) compressed size: {standard_gz_compressed_size} bytes")
 print(f" Standard (tar.gz) compression time: {standard_gz_compression_time:.4f} seconds")

 # Benchmark standard compression (bz2)
 standard_bz2_output_path = f"{dataset_path}.tar.bz2"
 intermediate_tar_path_bz2 = f"{dataset_path}_bz2.tar"
 standard_bz2_start_time = time.time()
 with tarfile.open(intermediate_tar_path_bz2, 'w') as tar:
 tar.add(dataset_path, arcname='.')
 with open(intermediate_tar_path_bz2, 'rb') as tar_in, open(standard_bz2_output_path, 'wb') as bz2_out:
 compressed_data = bz2.compress(tar_in.read())
 bz2_out.write(compressed_data)
 standard_bz2_end_time = time.time()
 standard_bz2_compression_time = standard_bz2_end_time - standard_bz2_start_time
 standard_bz2_compressed_size = os.path.getsize(standard_bz2_output_path)
 os.remove(intermediate_tar_path_bz2)

 benchmark_results_comprehensive[data_type]['standard_tar_bz2'] = {
 'compressed_size': standard_bz2_compressed_size,
 'compression_time': standard_bz2_compression_time
 }
 print(f" Standard (tar.bz2) compressed size: {standard_bz2_compressed_size} bytes")
 print(f" Standard (tar.bz2) compression time: {standard_bz2_compression_time:.4f} seconds")

 # Benchmark standard compression (xz)
 standard_xz_output_path = f"{dataset_path}.tar.xz"
 intermediate_tar_path_xz = f"{dataset_path}_xz.tar"
 standard_xz_start_time = time.time()
 with tarfile.open(intermediate_tar_path_xz, 'w') as tar:
 tar.add(dataset_path, arcname='.')
 with open(intermediate_tar_path_xz, 'rb') as tar_in, open(standard_xz_output_path, 'wb') as xz_out:
 compressed_data = lzma.compress(tar_in.read())
 xz_out.write(compressed_data)
 standard_xz_end_time = time.time()
 standard_xz_compression_time = standard_xz_end_time - standard_xz_start_time
 standard_xz_compressed_size = os.path.getsize(standard_xz_output_path)
 os.remove(intermediate_tar_path_xz)

 benchmark_results_comprehensive[data_type]['standard_tar_xz'] = {
 'compressed_size': standard_xz_compressed_size,
 'compression_time': standard_xz_compression_time
 }
 print(f" Standard (tar.xz) compressed size: {standard_xz_compressed_size} bytes")
 print(f" Standard (tar.xz) compression time: {standard_xz_compression_time:.4f} seconds")

 # Benchmark pure Zstandard compression
 standard_zstd_output_path = f"{dataset_path}.zstd"
 standard_zstd_start_time = time.time()
 if HAS_ZSTD:
 compressed_data = zstandard.compress(data_to_compress_pure)
 with open(standard_zstd_output_path, 'wb') as out_f:
 out_f.write(compressed_data)
 standard_zstd_end_time = time.time()
 standard_zstd_compression_time = standard_zstd_end_time - standard_zstd_start_time
 standard_zstd_compressed_size = os.path.getsize(standard_zstd_output_path)

 benchmark_results_comprehensive[data_type]['standard_zstd'] = {
 'compressed_size': standard_zstd_compressed_size,
 'compression_time': standard_zstd_compression_time
 }
 print(f" Standard (pure ZSTD) compressed size: {standard_zstd_compressed_size} bytes")
 print(f" Standard (pure ZSTD) compression time: {standard_zstd_compression_time:.4f} seconds")
 else:
 print(" Standard (pure ZSTD) skipped: zstandard library not available.")
 benchmark_results_comprehensive[data_type]['standard_zstd'] = {
 'compressed_size': 0,
 'compression_time': 0
 }


 # Benchmark Brotli compression
 standard_brotli_output_path = f"{dataset_path}.br"
 standard_brotli_start_time = time.time()
 if brotli:
 compressed_data = brotli.compress(data_to_compress_pure)
 with open(standard_brotli_output_path, 'wb') as out_f:
 out_f.write(compressed_data)
 standard_brotli_end_time = time.time()
 standard_brotli_compression_time = standard_brotli_end_time - standard_brotli_start_time
 standard_brotli_compressed_size = os.path.getsize(standard_brotli_output_path)

 benchmark_results_comprehensive[data_type]['standard_brotli'] = {
 'compressed_size': standard_brotli_compressed_size,
 'compression_time': standard_brotli_compression_time
 }
 print(f" Standard (Brotli) compressed size: {standard_brotli_compressed_size} bytes")
 print(f" Standard (Brotli) compression time: {standard_brotli_compression_time:.4f} seconds")
 else:
 print(" Standard (Brotli) skipped: brotli library not available.")
 benchmark_results_comprehensive[data_type]['standard_brotli'] = {
 'compressed_size': 0,
 'compression_time': 0
 }


 # Benchmark pure LZ4 compression
 standard_lz4_output_path = f"{dataset_path}.lz4"
 standard_lz4_start_time = time.time()
 if lz4.frame:
 with lz4.frame.open(standard_lz4_output_path, 'wb') as lz4_out:
 lz4_out.write(data_to_compress_pure)
 standard_lz4_end_time = time.time()
 standard_lz4_compression_time = standard_lz4_end_time - standard_lz4_start_time
 standard_lz4_compressed_size = os.path.getsize(standard_lz4_output_path)

 benchmark_results_comprehensive[data_type]['standard_lz4'] = {
 'compressed_size': standard_lz4_compressed_size,
 'compression_time': standard_lz4_compression_time
 }
 print(f" Standard (pure LZ4) compressed size: {standard_lz4_compressed_size} bytes")
 print(f" Standard (pure LZ4) compression time: {standard_lz4_compression_time:.4f} seconds")
 else:
 print(" Standard (pure LZ4) skipped: lz4.frame library not available.")
 benchmark_results_comprehensive[data_type]['standard_lz4'] = {
 'compressed_size': 0,
 'compression_time': 0
 }


# Print the collected results
print("\n--- Comprehensive Real-world Dataset Benchmark Results (with ZSTD levels and more standard methods) ---")
import json
print(json.dumps(benchmark_results_comprehensive, indent=2))

# Visualize results
print("\n--- Visualizing Results ---")
data_types = list(benchmark_results_comprehensive.keys())

for data_type in data_types:
 results = benchmark_results_comprehensive[data_type]
 original_size = results['original_size']

 # Extract method names, sizes, times, and calculate ratios
 method_names = ['Original']
 sizes_kb = [original_size / 1024]
 times_sec = [0] # Time for original is 0
 ratios = [1.0] # Ratio for original is 1.0

 method_data = {}
 for method, method_results in results.items():
 if method == 'original_size':
 continue
 method_data[method] = {
 'compressed_size': method_results['compressed_size'],
 'compression_time': method_results['compression_time']
 }

 # Sort methods for consistent plotting order
 sorted_methods = sorted(method_data.keys(), key=lambda x: (x.split('_')[0], int(x.split('_')[-1]) if x.startswith('gmw_zstd_') else x))

 for method in sorted_methods:
 compressed_size = method_data[method]['compressed_size']
 compression_time = method_data[method]['compression_time']

 method_names.append(method)
 sizes_kb.append(compressed_size / 1024)
 times_sec.append(compression_time)
 ratio = original_size / compressed_size if compressed_size > 0 else 0
 ratios.append(ratio)

 x = np.arange(len(method_names))

 # Create subplots for size and time
 fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 12))

 # Plot Compression Size
 bars1 = ax1.bar(x, sizes_kb, label='Size (KB)')
 ax1.set_ylabel('Size (KB)')
 ax1.set_title(f'Compression Size by Method for {data_type.capitalize()} Data')
 ax1.set_xticks(x)
 ax1.set_xticklabels(method_names, rotation=45, ha="right")
 ax1.legend()

 def autolabel_ratio(bars, ratios):
 for bar, ratio in zip(bars, ratios):
 height = bar.get_height()
 ax1.annotate(f'{ratio:.2f}',
 xy=(bar.get_x() + bar.get_width() / 2, height),
 xytext=(0, 3),
 textcoords="offset points",
 ha='center', va='bottom')

 autolabel_ratio(bars1, ratios)

 # Plot Compression Time
 bars2 = ax2.bar(x[1:], times_sec[1:], label='Time (seconds)', color='orange')
 ax2.set_ylabel('Time (seconds)')
 ax2.set_title(f'Compression Time by Method for {data_type.capitalize()} Data')
 ax2.set_xticks(x)
 ax2.set_xticklabels(method_names, rotation=45, ha="right")
 ax2.legend()

 fig.tight_layout()
 plt.show()

print("\nVisualization complete.")


# Analyze and present results
print("\n--- Analysis and Summary ---")
print("\n--- Comprehensive Real-world Dataset Compression Benchmark Results (with ZSTD levels and more standard methods) ---")

for data_type, results in benchmark_results_comprehensive.items():
 original_size = results['original_size']
 original_size_kb = original_size / 1024

 print(f"\nBenchmarking Results for {data_type.capitalize()} Data:")
 print(f" Original Size: {original_size_kb:.2f} KB")

 # Print results for each compression method/level
 for method, method_results in results.items():
 if method == 'original_size':
 continue

 compressed_size = method_results['compressed_size']
 compression_time = method_results['compression_time']

 compressed_size_kb = compressed_size / 1024
 compression_ratio = original_size / compressed_size if compressed_size > 0 else float('inf')

 print(f" {method}:")
 print(f" Compressed Size: {compressed_size_kb:.2f} KB")
 print(f" Compression Time: {compression_time:.4f} seconds")
 print(f" Compression Ratio: {compression_ratio:.2f}")

# High-level summary
print("\n--- Overall Summary ---")
print("Comparison of Compression Methods on Real-world Datasets:")

summary_data = {}
data_types = list(benchmark_results_comprehensive.keys())
method_names_list = []

for data_type in data_types:
 results = benchmark_results_comprehensive[data_type]
 original_size = results['original_size']
 summary_data[data_type] = {}
 for method, method_results in results.items():
 if method == 'original_size':
 continue
 if method not in method_names_list:
 method_names_list.append(method)
 compressed_size = method_results['compressed_size']
 compression_time = method_results['compression_time']
 compression_ratio = original_size / compressed_size if compressed_size > 0 else float('inf')
 summary_data[data_type][method] = {'ratio': compression_ratio, 'time': compression_time}

method_names_list.sort()

print("\nCompression Ratio Summary:")
header = ["Data Type"] + method_names_list
print("\t".join(header))
for data_type in data_types:
 row = [data_type.capitalize()] + [f"{summary_data[data_type].get(method, {}).get('ratio', float('nan')):.2f}" for method in method_names_list]
 print("\t".join(row))

print("\nCompression Time Summary (seconds):")
header = ["Data Type"] + method_names_list
print("\t".join(header))
for data_type in data_types:
 row = [data_type.capitalize()] + [f"{summary_data[data_type].get(method, {}).get('time', float('nan')):.4f}" for method in method_names_list]
 print("\t".join(row))

print("\nKey Observations:")
gmw_zstd_levels_methods = [method for method in method_names_list if method.startswith('gmw_zstd_')]
standard_methods = [method for method in method_names_list if method.startswith('standard_')]

for data_type in data_types:
 print(f"\n- {data_type.capitalize()} Data:")
 dataset_summary = summary_data[data_type]

 print(" GMW (ZSTD Levels) Comparison:")
 gmw_zstd_levels_methods.sort(key=lambda x: int(x.split('_')[-1]))
 for i in range(len(gmw_zstd_levels_methods) - 1):
 method1 = gmw_zstd_levels_methods[i]
 method2 = gmw_zstd_levels_methods[i+1]
 level1 = int(method1.split('_')[-1])
 level2 = int(method2.split('_')[-1])

 ratio1 = dataset_summary[method1]['ratio']
 ratio2 = dataset_summary[method2]['ratio']
 time1 = dataset_summary[method1]['time']
 time2 = dataset_summary[method2]['time']

 if ratio2 > ratio1:
 print(f" ZSTD Level {level2} achieved better compression ratio than Level {level1} ({ratio2:.2f} vs {ratio1:.2f}).")
 elif ratio2 < ratio1:
 print(f" ZSTD Level {level2} achieved worse compression ratio than Level {level1} ({ratio2:.2f} vs {ratio1:.2f}).")
 else:
 print(f" ZSTD Level {level2} and Level {level1} achieved similar compression ratio ({ratio2:.2f}).")

 if time2 < time1:
 print(f" ZSTD Level {level2} was faster than Level {level1} ({time2:.4f}s vs {time1:.4f}s).")
 elif time2 > time1:
 print(f" ZSTD Level {level2} was slower than Level {level1} ({time2:.4f}s vs {time1:.4f}s).")
 else:
 print(f" ZSTD Level {level2} and Level {level1} had similar compression times ({time2:.4f}s).")

 if gmw_zstd_levels_methods:
 best_gmw_ratio_method = max(gmw_zstd_levels_methods, key=lambda method: dataset_summary[method]['ratio'])
 best_gmw_time_method = min(gmw_zstd_levels_methods, key=lambda method: dataset_summary[method]['time'])

 print(" GMW vs. Standard Methods Comparison:")
 print(f" Best GMW Ratio ({best_gmw_ratio_method}): Ratio {dataset_summary[best_gmw_ratio_method]['ratio']:.2f}, Time {dataset_summary[best_gmw_ratio_method]['time']:.4f}s")
 print(f" Fastest GMW ({best_gmw_time_method}): Ratio {dataset_summary[best_gmw_time_method]['ratio']:.2f}, Time {dataset_summary[best_gmw_time_method]['time']:.4f}s")

 for std_method in standard_methods:
 if std_method in dataset_summary:
 print(f" {std_method}: Ratio {dataset_summary[std_method]['ratio']:.2f}, Time {dataset_summary[std_method]['time']:.4f}s")

 if dataset_summary[best_gmw_ratio_method]['ratio'] > dataset_summary[std_method]['ratio']:
 print(f" Best GMW ratio ({dataset_summary[best_gmw_ratio_method]['ratio']:.2f}) is better than {std_method} ratio ({dataset_summary[std_method]['ratio']:.2f}).")
 elif dataset_summary[best_gmw_ratio_method]['ratio'] < dataset_summary[std_method]['ratio']:
 print(f" {std_method} ratio ({dataset_summary[std_method]['ratio']:.2f}) is better than Best GMW ratio ({dataset_summary[best_gmw_ratio_method]['ratio']:.2f}).")
 else:
 print(f" Best GMW and {std_method} achieved similar ratios ({dataset_summary[std_method]['ratio']:.2f}).")

 if dataset_summary[best_gmw_time_method]['time'] < dataset_summary[std_method]['time']:
 print(f" Fastest GMW time ({dataset_summary[best_gmw_time_method]['time']:.4f}s) is faster than {std_method} time ({dataset_summary[std_method]['time']:.4f}s).")
 elif dataset_summary[best_gmw_time_method]['time'] > dataset_summary[std_method]['time']:
 print(f" {std_method} time ({dataset_summary[std_method]['time']:.4f}s) is faster than Fastest GMW time ({dataset_summary[best_gmw_time_method]['time']:.4f}s).")
 else:
 print(f" Fastest GMW and {std_method} had similar times ({dataset_summary[std_method]['time']:.4f}s).")
 else:
 print(f" {std_method}: Results not available for this dataset.")

print("\nOverall Conclusion:")
print("The GMW tool with different ZSTD levels and standard compression methods (tar.gz, tar.bz2, tar.xz, pure Zstandard, Brotli, and LZ4) were benchmarked on real-world datasets.")
print("GMW with higher ZSTD levels generally achieves better compression ratios, often competitive with or better than tar.gz and pure Zstandard, while remaining significantly faster than tar.gz, tar.bz2, tar.xz, and Brotli.")
print("Standard methods like tar.bz2, tar.xz, and Brotli can achieve higher compression ratios than GMW, but with substantially longer compression times.")
print("Pure LZ4 is generally the fastest method but provides the lowest compression ratios.")
print("The optimal compression method depends on the specific requirements, balancing the need for smaller file sizes against the available time for compression.")


# Clean up
print("\n--- Cleaning Up ---")
# Remove the directory containing downloaded datasets
if 'dataset_dir' in globals() and os.path.exists(dataset_dir):
 shutil.rmtree(dataset_dir)
 print(f"Removed downloaded datasets directory: {dataset_dir}")

# Remove the temporary directory for prepared datasets
if 'temp_dataset_dir' in globals() and os.path.exists(temp_dataset_dir):
 shutil.rmtree(temp_dataset_dir)
 print(f"Removed temporary directory for prepared datasets: {temp_dataset_dir}")

print("\nBenchmarking complete and temporary files cleaned up.")