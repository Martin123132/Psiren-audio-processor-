#pragma once
#include <string>
#include <iostream>

class Logger {
public:
    // A simple, static function for logging
    static void Log(const std::string& message) {
        // A real logger would be thread-safe and write to a file.
        // This is a simple placeholder for std::cout.
        std::cout << "[PGF_Engine] " << message << std::endl;
    }
};