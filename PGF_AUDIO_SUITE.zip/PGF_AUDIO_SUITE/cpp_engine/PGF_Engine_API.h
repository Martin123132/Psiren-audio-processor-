#pragma once

// Use __declspec(dllexport) for Windows to export functions
// Use extern "C" to prevent C++ name mangling, so Python can find the functions
#ifdef _WIN32
    #define PGF_API extern "C" __declspec(dllexport)
#else
    #define PGF_API extern "C"
#endif

// --- API Functions ---
// We use an opaque "handle" (a void*) to represent our C++ object
// so Python doesn't need to know what a PGF_DSP is.

/**
 * @brief Creates a new PGF_DSP engine instance.
 * @return An opaque handle to the engine.
 */
PGF_API void* pgf_create_handle();

/**
 * @brief Destroys a PGF_DSP engine instance.
 * @param handle The handle to destroy.
 */
PGF_API void pgf_destroy_handle(void* handle);

/**
 * @brief Sets the filter parameters for a given engine.
 * @param handle The engine handle.
 * @param gamma The "strength" parameter.
 * @param K The "sensitivity" parameter.
 * @param steps The number of iterations.
 */
PGF_API void pgf_set_parameters(void* handle, float gamma, float K, int steps);

/**
 * @brief Processes an audio buffer in-place.
 * @param handle The engine handle.
 * @param buffer A pointer to the float audio data.
 * @param num_samples The number of samples in the buffer.
 */
PGF_API void pgf_process_inplace(void* handle, float* buffer, int num_samples);