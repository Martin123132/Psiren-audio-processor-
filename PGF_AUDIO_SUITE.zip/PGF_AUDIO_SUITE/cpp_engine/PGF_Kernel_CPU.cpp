#include "PGF_Kernel.h"
#include <cmath>
#include <vector>
#include <thread>
#include <algorithm>

// This is the core 1D PGF algorithm for a single step
static void pgf_step(float* d_out, const float* d_in, int n, float gamma, float k_sq, float dt) {
    
    // Handle thread-parallel processing
    // (This example is simplified for clarity, a real one would use a thread pool)
    
    for (int i = 0; i < n; ++i) {
        // Get neighbors with boundary clamping
        float u_c = d_in[i];
        float u_l = (i == 0) ? u_c : d_in[i - 1];
        float u_r = (i == n - 1) ? u_c : d_in[i + 1];

        // Calculate gradients
        float grad_l = u_l - u_c;
        float grad_r = u_r - u_c;

        // Calculate the "c" (diffusivity) for each direction based on PGF
        // c = gamma / (1 + (grad/K)^2) -> k_sq = K*K
        float c_l = gamma / (1.0f + (grad_l * grad_l) / k_sq);
        float c_r = gamma / (1.0f + (grad_r * grad_r) / k_sq);

        // Calculate the total flux (divergence)
        float flux = c_l * grad_l + c_r * grad_r;

        // Update the pixel value using Euler's method
        d_out[i] = u_c + dt * flux;
    }
}

// Public launcher function
void launch_pgf_kernel_cpu(float* buffer, int num_samples, const PGF_Parameters& params) {
    // Pre-calculate derived parameters
    float k_sq = params.K * params.K;
    if (k_sq == 0.0f) k_sq = 1e-6f; // Avoid divide-by-zero
    float dt = 0.2f; // Timestep (chosen for stability)

    // We need two buffers ("ping-pong" buffers)
    std::vector<float> buffer_a(num_samples);
    std::vector<float> buffer_b(num_samples);
    
    // Copy initial data
    std::copy(buffer, buffer + num_samples, buffer_a.begin());

    float* d_in = buffer_a.data();
    float* d_out = buffer_b.data();

    // Run the simulation loop
    for (int i = 0; i < params.steps; ++i) {
        pgf_step(d_out, d_in, num_samples, params.gamma, k_sq, dt);
        
        // Swap the 'in' and 'out' pointers for the next iteration
        std::swap(d_in, d_out);
    }
    
    // After the loop, d_in holds the final result (due to the swap)
    // Copy the final result back into the original buffer
    std::copy(d_in, d_in + num_samples, buffer);
}