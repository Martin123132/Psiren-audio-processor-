#include "PGF_Kernel.h"
#include <cuda_runtime.h>
#include <device_launch_parameters.h>

// --- CUDA Device Kernel ---
// This is the code that runs on each GPU core.

__device__ inline float get_sample(const float* data, int i, int n) {
    // Clamp edges
    if (i < 0) return data[0];
    if (i >= n) return data[n - 1];
    return data[i];
}

__global__ void pgf_kernel_step_1d(float* d_out, const float* d_in, int n, float gamma, float k_sq, float dt) {
    
    // Get the index this thread is responsible for
    int i = blockIdx.x * blockDim.x + threadIdx.x;

    if (i >= n) return; // Thread is outside the buffer

    // 1. Get neighboring pixel values
    float u_c = get_sample(d_in, i, n);
    float u_l = get_sample(d_in, i - 1, n);
    float u_r = get_sample(d_in, i + 1, n);

    // 2. Calculate gradients
    float grad_l = u_l - u_c;
    float grad_r = u_r - u_c;

    // 3. Calculate the "c" (diffusivity)
    float c_l = gamma / (1.0f + (grad_l * grad_l) / k_sq);
    float c_r = gamma / (1.0f + (grad_r * grad_r) / k_sq);

    // 4. Calculate the total flux
    float flux = c_l * grad_l + c_r * grad_r;

    // 5. Update the sample value
    d_out[i] = u_c + dt * flux;
}

// --- C++ "Launcher" Function ---
// This is called by PGF_DSP.cpp. It sets up and launches the CUDA kernel.

void launch_pgf_kernel_cuda(float* d_buffer, int num_samples, const PGF_Parameters& params) {
    
    // --- Setup ---
    int threads_per_block = 256;
    int blocks_per_grid = (num_samples + threads_per_block - 1) / threads_per_block;
    
    size_t size = num_samples * sizeof(float);
    
    // Allocate a temporary "out" buffer on the GPU
    float* d_out_buffer;
    cudaMalloc(&d_out_buffer, size);

    // Set pointers
    float* d_in = d_buffer;
    float* d_out = d_out_buffer;

    // --- Pre-calculate parameters ---
    float k_sq = params.K * params.K;
    if (k_sq == 0.0f) k_sq = 1e-6f;
    float dt = 0.2f;

    // --- Simulation Loop ---
    for (int i = 0; i < params.steps; ++i) {
        // Launch the kernel
        pgf_kernel_step_1d<<<blocks_per_grid, threads_per_block>>>(
            d_out, d_in, num_samples, params.gamma, k_sq, dt
        );
        
        // Swap pointers (zero-copy)
        std::swap(d_in, d_out);
    }
    
    // --- Finalize ---
    // If we swapped an odd number of times, the final data is in d_out_buffer.
    // We must copy it back to the original d_buffer.
    if (params.steps % 2 != 0) {
        cudaMemcpy(d_buffer, d_out_buffer, size, cudaMemcpyDeviceToDevice);
    }

    // Free the temporary buffer
    cudaFree(d_out_buffer);
}