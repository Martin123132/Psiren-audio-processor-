#pragma once
#include <vector>

// Forward-declare the internal "implementation"
// This is the Pimpl idiom, which hides complex
// implementation details (like GPU/CPU state) from the header.
struct PGF_DSP_Impl;

class PGF_DSP {
public:
    // Enum to select processing mode
    enum class Device {
        CPU_Auto,
        GPU_NVIDIA,
        GPU_OpenCL
    };

    /**
     * @brief Constructs the PGF processing engine.
     * @param device The compute device to use.
     */
    PGF_DSP(Device device = Device::CPU_Auto);

    /**
     * @brief Destructor.
     */
    ~PGF_DSP();

    /**
     * @brief Sets the filter parameters.
     * @param gamma The "strength" of the filter (0.0 to 1.0).
     * @param K     The "sensitivity" threshold (0.0 to 1.0).
     * @param steps The number of iterations (1 to 100).
     */
    void set_parameters(float gamma, float K, int steps);

    /**
     * @brief Processes an audio buffer in-place.
     * @param buffer A pointer to the audio data (float, -1.0 to 1.0).
     * @param num_samples The number of samples in the buffer.
     */
    void process_inplace(float* buffer, int num_samples);

    /**
     * @brief Detects clipped samples in a buffer.
     * @param buffer A pointer to the audio data.
     * @param num_samples The number of samples.
     * @param threshold The level to consider "clipped" (e.g., 0.98).
     * @return A vector of sample indices that are clipped.
     */
    std::vector<int> detect_clips(const float* buffer, int num_samples, float threshold);

private:
    // Pointer to the internal implementation
    PGF_DSP_Impl* m_impl;
};