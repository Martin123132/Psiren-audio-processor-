#include "PGF_Engine_API.h"
#include "PGF_DSP.h"

// --- API Implementation ---

PGF_API void* pgf_create_handle() {
    // Create a new PGF_DSP object on the heap and cast it to void*
    // We can select the device here (e.g., PGF_DSP::Device::GPU_NVIDIA)
    PGF_DSP* engine = new PGF_DSP(PGF_DSP::Device::CPU_Auto);
    return static_cast<void*>(engine);
}

PGF_API void pgf_destroy_handle(void* handle) {
    if (handle) {
        // Cast the void* back to PGF_DSP* and delete it
        PGF_DSP* engine = static_cast<PGF_DSP*>(handle);
        delete engine;
    }
}

PGF_API void pgf_set_parameters(void* handle, float gamma, float K, int steps) {
    if (handle) {
        // Cast, then call the C++ class method
        PGF_DSP* engine = static_cast<PGF_DSP*>(handle);
        engine->set_parameters(gamma, K, steps);
    }
}

PGF_API void pgf_process_inplace(void* handle, float* buffer, int num_samples) {
    if (handle && buffer) {
        // Cast, then call the C++ class method
        PGF_DSP* engine = static_cast<PGF_DSP*>(handle);
        engine->process_inplace(buffer, num_samples);
    }
}