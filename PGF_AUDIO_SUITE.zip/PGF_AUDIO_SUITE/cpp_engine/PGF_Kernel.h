#pragma once

// A simple struct to pass parameters to the kernels
struct PGF_Parameters {
    float gamma;
    float K;
    int steps;
    
    // Pre-calculate for efficiency
    float K_squared;
    float dt; // Timestep
};

/**
 * @brief Launches the 1D PGF kernel on the CPU (multi-threaded).
 * @param buffer The audio buffer to process in-place.
 * @param num_samples The number of samples.
 * @param params The struct of filter parameters.
 */
void launch_pgf_kernel_cpu(float* buffer, int num_samples, const PGF_Parameters& params);

/**
 * @brief Launches the 1D PGF kernel on the GPU (CUDA).
 * @param d_buffer A pointer to the data *already on the GPU*.
 * @param num_samples The number of samples.
 * @param params The struct of filter parameters.
 */
void launch_pgf_kernel_cuda(float* d_buffer, int num_samples, const PGF_Parameters& params);