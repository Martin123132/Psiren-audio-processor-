#include "PGF_DSP.h"
#include "PGF_Kernel.h"   // Our internal compute kernel header
#include "PGF_Utils.h"    // Our logging utility

// This struct holds the actual state (e.g., GPU memory pointers)
struct PGF_DSP_Impl {
    PGF_DSP::Device compute_device;
    PGF_Parameters params;
    
    // This could also hold allocated GPU buffers, etc.
    // float* d_buffer; // (Device buffer)

    PGF_DSP_Impl(PGF_DSP::Device device) : compute_device(device) {
        // Set default parameters
        params.gamma = 0.1f;
        params.K = 0.1f;
        params.steps = 5;
        
        Logger::Log("PGF_DSP_Impl initialized for " + std::to_string((int)device));
        // Here you would initialize CUDA/OpenCL if GPU is selected
    }

    ~PGF_DSP_Impl() {
        Logger::Log("PGF_DSP_Impl destroyed.");
        // Here you would free any GPU resources
    }
};

// --- Public Class Implementation ---

PGF_DSP::PGF_DSP(Device device) {
    // Allocate the internal implementation
    m_impl = new PGF_DSP_Impl(device);
}

PGF_DSP::~PGF_DSP() {
    delete m_impl;
}

void PGF_DSP::set_parameters(float gamma, float K, int steps) {
    m_impl->params.gamma = gamma;
    m_impl->params.K = K;
    m_impl->params.steps = steps;
    Logger::Log("Parameters set: G=" + std::to_string(gamma) + ", K=" + std::to_string(K) + ", N=" + std::to_string(steps));
}

void PGF_DSP::process_inplace(float* buffer, int num_samples) {
    if (m_impl->compute_device == Device::GPU_NVIDIA) {
        // --- GPU (CUDA) Path ---
#ifdef USE_CUDA
        launch_pgf_kernel_cuda(buffer, num_samples, m_impl->params);
#else
        // CUDA not available, fall back to CPU
        Logger::Log("CUDA requested but not available, using CPU");
        launch_pgf_kernel_cpu(buffer, num_samples, m_impl->params);
#endif
    } else {
        // --- CPU Path ---
        launch_pgf_kernel_cpu(buffer, num_samples, m_impl->params);
    }
}

std::vector<int> PGF_DSP::detect_clips(const float* buffer, int num_samples, float threshold) {
    std::vector<int> clipped_indices;
    for (int i = 0; i < num_samples; ++i) {
        if (std::abs(buffer[i]) >= threshold) {
            clipped_indices.push_back(i);
        }
    }
    return clipped_indices;
}