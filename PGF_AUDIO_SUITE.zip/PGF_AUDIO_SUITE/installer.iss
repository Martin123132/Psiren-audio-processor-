; Inno Setup Script for PGF Audio Suite

[Setup]
AppName=PGF Audio Suite
AppVersion=1.0.0
AppPublisher=Glyn
DefaultDirName={autopf}\PGF_Audio_Suite
PrivilegesRequired=admin
OutputBaseFilename=PGF_Audio_Suite_Installer
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop icon"; GroupDescription: "Additional Icons:";
Name: "installvst"; Description: "Install VST3 Plugin (for musicians)"; GroupDescription: "Components:"; Flags: checkedonce

[Files]
; 1. The main Python Application (from your setup.py build)
Source: "C:\path\to\your\build\output\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs

; 2. The VST3 Plugin (from your CMake build)
Source: "C:\path\to\your\cmake\build\PGF_Warmth.vst3\*"; DestDir: "{cf}\Common Files\VST3"; Flags: recursesubdirs; Tasks: installvst

; 3. The Virtual Mic Driver Installer (if you have one)
; Source: "drivers\VirtualMicInstaller.exe"; DestDir: "{tmp}"; Flags: deleteafterinstall

[Icons]
Name: "{autoprograms}\PGF Audio Suite"; Filename: "{app}\pgf_audio.exe"
Name: "{autodesktop}\PGF Audio Suite"; Filename: "{app}\pgf_audio.exe"; Tasks: desktopicon

[Run]
; Run the VC++ Redistributable (if needed)
; Filename: "{app}\vc_redist.x64.exe"; Parameters: "/install /quiet /norestart";