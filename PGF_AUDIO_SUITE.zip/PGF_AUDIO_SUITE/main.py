import sys
from PyQt5.QtWidgets import QApplication
from pgf_app.core.logger import setup_logging
from pgf_app.core.config_loader import load_config
from pgf_app.ui.main_window import MainWindow

# --- 1. Initialize Logger ---
# We set this up first so we can log everything that happens.
log = setup_logging()

def main():
    log.info("========================================")
    log.info("PGF Audio Suite v1.0.0 Starting...")
    log.info("========================================")

    # --- 2. Initialize Configuration ---
    try:
        load_config()
        log.info("Configuration file loaded successfully.")
    except Exception as e:
        log.critical(f"Failed to load configuration: {e}")
        # (In a real app, you'd show an error pop-up)
        return -1

    # --- 3. Initialize the Qt Application ---
    app = QApplication(sys.argv)
    
    # (Optional: Add styling/theme loading here)

    # --- 4. Launch Main Window ---
    try:
        main_window = MainWindow()
        main_window.show()
        log.info("MainWindow loaded and shown.")
        
        # --- 5. Start the Event Loop ---
        sys.exit(app.exec_())
    
    except Exception as e:
        log.critical(f"Unhandled exception in main: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()