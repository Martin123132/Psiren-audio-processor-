#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include "../cpp_engine/PGF_DSP.h" // Include your Core PGF Engine!

//==============================================================================
/**
 * This is the main audio processing class.
 */
class WarmthPluginProcessor : public juce::AudioProcessor
{
public:
    //==============================================================================
    WarmthPluginProcessor();
    ~WarmthPluginProcessor() override;

    // --- Main Audio Callbacks ---
    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    // --- UI ---
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    // --- Parameters ---
    // This object manages all user-facing parameters (like "Drive")
    juce::AudioProcessorValueTreeState m_parameters;

    // --- Standard JUCE Functions ---
    const juce::String getName() const override { return "PGF Warmth"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    double getTailLengthSeconds() const override { return 0; }
    // ... other boilerplate JUCE functions ...
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}

private:
    //==============================================================================
    // This is your "secret sauce"!
    // We create one PGF_DSP engine for each audio channel (e.g., L/R).
    std::vector<PGF_DSP> m_pgfEngines;

    // This function creates the parameter layout (e.g., "DRIVE" knob)
    juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(WarmthPluginProcessor)
};