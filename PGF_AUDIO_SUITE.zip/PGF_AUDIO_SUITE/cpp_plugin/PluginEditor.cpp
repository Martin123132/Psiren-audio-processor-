#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
WarmthPluginEditor::WarmthPluginEditor(WarmthPluginProcessor& p)
    : juce::AudioProcessorEditor(&p), processor(p) // Initializer list
{
    // --- "Drive" Knob ---
    addAndMakeVisible(driveKnob);
    driveKnob.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    driveKnob.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
    driveKnob.setPopupDisplayEnabled(true, false, this);
    driveKnob.setTextValueSuffix(" Drive");

    // --- "Drive" Label ---
    addAndMakeVisible(driveLabel);
    driveLabel.setText("Drive", juce::dontSendNotification);
    driveLabel.attachToComponent(&driveKnob, false);
    driveLabel.setJustificationType(juce::Justification::centred);

    // --- Parameter Attachment ---
    // This is the "magic" that links the UI knob to the audio processor's
    // internal "drive" parameter.
    driveAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
        processor.m_parameters, // The processor's parameter list
        "DRIVE",                // The ID of the parameter
        driveKnob               // The UI slider to attach
    );

    // Set the size of the plugin window
    setSize(200, 300);
}

WarmthPluginEditor::~WarmthPluginEditor()
{
}

//==============================================================================
void WarmthPluginEditor::paint(juce::Graphics& g)
{
    // Fill the background with a solid color
    g.fillAll(juce::Colours::black.darker(0.7f));
}

void WarmthPluginEditor::resized()
{
    // This function lays out the knobs on the screen.
    // Place the "Drive" knob in the center.
    driveKnob.setBounds(getLocalBounds().reduced(50));
}

void WarmthPluginEditor::sliderValueChanged(juce::Slider* slider)
{
    // This is where you'd handle slider changes *if not* using attachments.
    // Since we are using attachments, this can be empty.
}