#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
WarmthPluginProcessor::WarmthPluginProcessor()
    : juce::AudioProcessor(BusesProperties().withInput("Input", juce::AudioChannelSet::stereo(), true)
                                          .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      m_parameters(*this, nullptr, "PARAMETERS", createParameterLayout()) // Initialize parameters
{
    // Constructor
}

WarmthPluginProcessor::~WarmthPluginProcessor()
{
}

//==============================================================================
juce::AudioProcessorValueTreeState::ParameterLayout WarmthPluginProcessor::createParameterLayout()
{
    // This defines the "knobs" the user can control
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    // The "Drive" knob
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "DRIVE",     // Parameter ID
        "Drive",     // Parameter Name
        0.0f,        // Min Value
        100.0f,      // Max Value
        0.0f         // Default Value
    ));

    return { params.begin(), params.end() };
}

//==============================================================================
void WarmthPluginProcessor::prepareToPlay(double sampleRate, int samplesPerBlock)
{
    // This is called before playback starts.
    // Create one PGF_DSP engine for each channel.
    int numChannels = getTotalNumInputChannels();
    m_pgfEngines.clear();
    for (int i = 0; i < numChannels; ++i) {
        m_pgfEngines.emplace_back(PGF_DSP::Device::CPU_Auto);
    }
}

void WarmthPluginProcessor::releaseResources()
{
    // Called when playback stops. Clear the engines.
    m_pgfEngines.clear();
}

//==============================================================================
void WarmthPluginProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    // --- 1. Get current parameter values from the UI ---
    float drive = *m_parameters.getRawParameterValue("DRIVE");
    
    // --- 2. Calculate PGF settings based on "Drive" ---
    // This is where you translate "Drive" into your PGF knobs
    // A simple mapping:
    float inputGain = 1.0f + (drive / 100.0f) * 20.0f; // Add up to 20x gain
    float K_val = 0.5f - (drive / 100.0f) * 0.4f;   // As drive goes up, sensitivity (K) goes down
    float Gamma_val = 0.1f + (drive / 100.0f) * 0.5f; // As drive goes up, strength (G) goes up
    int Steps = 2 + (int)(drive / 20.0f); // More steps as it gets hotter

    // --- 3. Process each channel ---
    for (int channel = 0; channel < buffer.getNumChannels(); ++channel)
    {
        // Get a pointer to the audio data for this channel
        float* channelData = buffer.getWritePointer(channel);
        int numSamples = buffer.getNumSamples();

        // Get the PGF engine for this channel
        auto& engine = m_pgfEngines[channel];

        // --- 4. Apply the "Drive" (Pre-Gain) ---
        for (int i = 0; i < numSamples; ++i) {
            channelData[i] *= inputGain;
        }

        // --- 5. Run the PGF Engine ---
        // This is where your saturation (soft-clipping) happens.
        // The engine "smooths" the hard clips caused by the gain.
        engine.set_parameters(Gamma_val, K_val, Steps);
        engine.process_inplace(channelData, numSamples);
        
        // --- 6. (Optional) Apply Output Gain ---
        // ...
    }
}

//==============================================================================
juce::AudioProcessorEditor* WarmthPluginProcessor::createEditor()
{
    // Create the UI window
    return new WarmthPluginEditor(*this);
}