#pragma once

/*
  ==============================================================================

    PGF_WarmthPlugin.h
    
    This is the main header file for the PGF Warmth Plugin.
    It's a convenient file to include in other parts of the project,
    and it brings in both the Processor and Editor.

  ==============================================================================
*/

// --- Core JUCE Includes ---
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_gui_basics/juce_gui_basics.h>

// --- Our Plugin Includes ---
#include "PluginProcessor.h"
#include "PluginEditor.h"