#pragma once

#include "PluginProcessor.h"
#include <juce_gui_basics/juce_gui_basics.h>

//==============================================================================
/**
 * This is the UI class for our PGF Warmth plugin.
 */
class WarmthPluginEditor : public juce::AudioProcessorEditor,
                           private juce::Slider::Listener // Listens for knob changes
{
public:
    // Constructor
    WarmthPluginEditor(WarmthPluginProcessor&);
    // Destructor
    ~WarmthPluginEditor() override;

    // --- JUCE UI Functions ---
    void paint(juce::Graphics&) override;
    void resized() override;

private:
    // --- UI Listeners ---
    /** Called when the slider's value is changed by the user. */
    void sliderValueChanged(juce::Slider* slider) override;

    // --- Data Members ---
    
    // A reference to the audio processor (the "backend")
    WarmthPluginProcessor& processor;

    // Our main "Drive" knob
    juce::Slider driveKnob;
    
    // Labels for the UI
    juce::Label driveLabel;
    
    // We need this to link the UI knob to the processor's parameter
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> driveAttachment;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(WarmthPluginEditor)
};