from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton
from PyQt5.QtCore import pyqtSignal
from ..core.logger import log

class DeclipPanel(QWidget):
    """
    UI panel for the De-Clip (Repair) module.
    """
    # Signal to tell the Studio page to run an action
    detect_clips = pyqtSignal()
    repair_clips = pyqtSignal(dict)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        
        button_layout = QHBoxLayout()
        
        self.detect_button = QPushButton("Detect Clips")
        self.detect_button.clicked.connect(self.detect_clips.emit)
        
        self.repair_button = QPushButton("Repair All Clips")
        self.repair_button.clicked.connect(self.on_repair)
        
        button_layout.addWidget(self.detect_button)
        button_layout.addWidget(self.repair_button)
        
        layout.addLayout(button_layout)
        layout.addStretch()

        log.debug("DeclipPanel initialized.")
        
    def on_repair(self):
        """
        When 'Repair' is clicked, it emits the PGF settings
        to be used for the repair.
        """
        # De-clipping uses very specific, strong settings
        params = {
            'gamma': 0.8,  # High strength
            'k_value': 0.01, # High sensitivity (low K)
            'steps': 20    # High quality
        }
        self.repair_clips.emit(params)