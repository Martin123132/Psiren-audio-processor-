from PyQt5.QtWidgets import QWidget, QFormLayout, QSlider
from PyQt5.QtCore import Qt, pyqtSignal
from ..core.logger import log

class DeclickPanel(QWidget):
    """
    UI panel for the De-Click module.
    """
    params_changed = pyqtSignal(dict)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        layout = QFormLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)

        # --- Sensitivity ---
        # A high value means it will look for bigger clicks
        self.sensitivity_slider = QSlider(Qt.Orientation.Horizontal)
        self.sensitivity_slider.setRange(1, 100)
        self.sensitivity_slider.setValue(50)
        self.sensitivity_slider.valueChanged.connect(self.on_params_changed)
        layout.addRow("Sensitivity:", self.sensitivity_slider)
        
        log.debug("DeclickPanel initialized.")

    def on_params_changed(self):
        """
        This would translate 'Sensitivity' into PGF params.
        De-clicking is complex; this is a placeholder.
        """
        sensitivity = self.sensitivity_slider.value()
        
        # A simple mapping:
        # High sensitivity = higher K (less sensitive filter)
        # to *only* catch the big spikes.
        params = {
            'gamma': 0.5, # Fixed medium strength
            'k_value': sensitivity / 100.0,
            'steps': 3    # Fast
        }
        self.params_changed.emit(params)