from PyQt5.QtWidgets import QWidget, QVBoxLayout, QFormLayout, QSlider, QLabel, QPushButton
from PyQt5.QtCore import Qt, pyqtSignal
from ..core.logger import log

class DenoisePanel(QWidget):
    """
    UI panel for the Denoise module.
    Emits a signal when its parameters are changed.
    """
    # Signal: emits a dict of the current settings
    params_changed = pyqtSignal(dict)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        layout = QFormLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        # --- Strength (Gamma) ---
        self.strength_slider = QSlider(Qt.Orientation.Horizontal)
        self.strength_slider.setRange(0, 100) # 0 to 100%
        self.strength_slider.setRange(0, 100) # 0 to 100%
        self.strength_slider.setValue(30)
        self.strength_slider.valueChanged.connect(self.on_params_changed)
        layout.addRow("Strength (Gamma):", self.strength_slider)
        # --- Sensitivity (K) ---
        self.sensitivity_slider = QSlider(Qt.Orientation.Horizontal)
        self.sensitivity_slider.setRange(1, 100) # 0.01 to 1.0
        self.sensitivity_slider.setRange(1, 100) # 0.01 to 1.0
        self.sensitivity_slider.setValue(10)
        self.sensitivity_slider.valueChanged.connect(self.on_params_changed)
        layout.addRow("Sensitivity (K):", self.sensitivity_slider)
        # --- Steps (N) ---
        self.steps_slider = QSlider(Qt.Orientation.Horizontal)
        self.steps_slider.setRange(1, 50)
        self.steps_slider.setRange(1, 50)
        self.steps_slider.setValue(5)
        self.steps_slider.valueChanged.connect(self.on_params_changed)
        layout.addRow("Quality (Steps):", self.steps_slider)
        
        # --- Learn Button ---
        self.learn_button = QPushButton("Learn Noise Profile")
        self.learn_button.clicked.connect(self.on_learn)
        layout.addRow(self.learn_button)

        log.debug("DenoisePanel initialized.")
        
    def on_params_changed(self):
        """Emits the current settings as a dictionary."""
        params = {
            'gamma': self.strength_slider.value() / 100.0,
            'k_value': self.sensitivity_slider.value() / 100.0,
            'steps': self.steps_slider.value()
        }
        self.params_changed.emit(params)
        
    def get_params(self):
        """Returns the current settings."""
        return {
            'gamma': self.strength_slider.value() / 100.0,
            'k_value': self.sensitivity_slider.value() / 100.0,
            'steps': self.steps_slider.value()
        }
    
    def on_learn(self):
        """Learn noise profile from selected audio region."""
        # In a full implementation, this would:
        # 1. Get the selected region from waveform editor
        # 2. Analyze its spectral characteristics
        # 3. Auto-adjust strength/sensitivity sliders
        # For now, provide user feedback
        log.info("Learn Noise Profile: Select a quiet region containing only noise, then click Learn.")
        # Auto-set conservative denoising parameters
        self.strength_slider.setValue(25)
        self.sensitivity_slider.setValue(15)
        self.on_params_changed()