from PyQt5.QtWidgets import QWidget, QVBoxLayout, QDial, QLabel
from PyQt5.QtCore import Qt, pyqtSignal
from ..core.logger import log

class ClarityPanel(QWidget):
    """
    UI panel for the one-knob "Clarity" (Enhancement) module.
    """
    params_changed = pyqtSignal(dict)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.clarity_knob = QDial()
        self.clarity_knob.setRange(0, 100)
        self.clarity_knob.setValue(0)
        self.clarity_knob.setNotchesVisible(True)
        self.clarity_knob.setFixedSize(150, 150)
        
        self.clarity_label = QLabel("CLARITY: 0%")
        self.clarity_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        layout.addWidget(self.clarity_knob)
        layout.addWidget(self.clarity_label)
        
        self.clarity_knob.valueChanged.connect(self.on_knob_changed)
        log.debug("ClarityPanel initialized.")

    def on_knob_changed(self, value):
        """Translate the single knob into a complex set of params."""
        self.clarity_label.setText(f"CLARITY: {value}%")
        
        clarity = value / 100.0
        
        # This is the "secret sauce" of this module.
        # As clarity goes up, we apply *gentle* denoising (low G)
        # but with *high* transient preservation (low K).
        
        params = {
            'gamma': 0.1 + (clarity * 0.1), # Very gentle strength
            'k_value': 0.1 - (clarity * 0.09), # Very low K (high sensitivity)
            'steps': 3
        }
        self.params_changed.emit(params)