from PyQt5.QtWidgets import QWidget, QVBoxLayout, QFormLayout, QComboBox, \
                            QSlider, QCheckBox, QLabel, QPushButton, QProgressBar, QHBoxLayout
from PyQt5.QtCore import Qt, Qt as QtCore
from ..core.logger import log
from ..core.audio_stream_service import AudioStreamService
from ..core.config_loader import set_setting
import sounddevice as sd
import os
import soundfile as sf
from datetime import datetime

class PageLive(QWidget):
    """
    The UI page for the "Live Filter" mode.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # --- Core Service ---
        # We create the service, but it will be run in a QThread
        # by the main window to keep it off the GUI thread.
        self.stream_service = AudioStreamService()

        # --- UI Layout ---
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        form_widget = QWidget()
        form_widget.setFixedWidth(400)
        form_layout = QFormLayout(form_widget)
        
        # --- Audio Devices ---
        self.input_combo = QComboBox()
        self.output_combo = QComboBox()
        self.refresh_devices()
        
        self.refresh_btn = QPushButton("Refresh Devices")
        self.refresh_btn.clicked.connect(self.refresh_devices)
        
        form_layout.addRow(self.refresh_btn)
        form_layout.addRow("Input Microphone:", self.input_combo)
        form_layout.addRow("Output (Virtual Mic):", self.output_combo)
        
        # --- Filter Controls ---
        self.denoise_slider = QSlider(Qt.Orientation.Horizontal)
        self.denoise_slider.setRange(0, 100) # 0-100%
        self.denoise_slider.setValue(30)

        # Sensitivity (K)
        self.k_slider = QSlider(Qt.Orientation.Horizontal)
        self.k_slider.setRange(1, 100)  # maps to 0.01 - 1.0
        self.k_slider.setValue(10)

        # Quality (Steps)
        self.steps_slider = QSlider(Qt.Orientation.Horizontal)
        self.steps_slider.setRange(1, 50)
        self.steps_slider.setValue(5)
        
        self.anticlip_check = QCheckBox("Enable Anti-Clip")
        self.anticlip_check.setChecked(True)
        
        form_layout.addRow("Denoise Amount:", self.denoise_slider)
        form_layout.addRow("Sensitivity (K):", self.k_slider)
        form_layout.addRow("Quality (Steps):", self.steps_slider)
        form_layout.addRow("", self.anticlip_check)
        
        # --- Level Meters ---
        meter_layout = QVBoxLayout()
        
        input_meter_layout = QHBoxLayout()
        input_label = QLabel("Input:")
        input_label.setFixedWidth(50)
        self.input_meter = QProgressBar()
        self.input_meter.setRange(0, 100)
        self.input_meter.setValue(0)
        self.input_meter.setTextVisible(True)
        self.input_meter.setFormat("%v dB")
        self.input_meter.setStyleSheet("QProgressBar::chunk { background-color: #4CAF50; }")
        input_meter_layout.addWidget(input_label)
        input_meter_layout.addWidget(self.input_meter)
        
        output_meter_layout = QHBoxLayout()
        output_label = QLabel("Output:")
        output_label.setFixedWidth(50)
        self.output_meter = QProgressBar()
        self.output_meter.setRange(0, 100)
        self.output_meter.setValue(0)
        self.output_meter.setTextVisible(True)
        self.output_meter.setFormat("%v dB")
        self.output_meter.setStyleSheet("QProgressBar::chunk { background-color: #2196F3; }")
        output_meter_layout.addWidget(output_label)
        output_meter_layout.addWidget(self.output_meter)
        
        meter_layout.addLayout(input_meter_layout)
        meter_layout.addLayout(output_meter_layout)
        form_layout.addRow("", meter_layout)

        # --- Start/Stop Button ---
        self.start_stop_button = QPushButton("Start Filter")
        self.start_stop_button.setCheckable(True)
        self.start_stop_button.clicked.connect(self.toggle_stream)
        
        self.record_button = QPushButton("Start Recording")
        self.record_button.setCheckable(True)
        self.record_button.clicked.connect(self.toggle_recording)
        self.record_button.setEnabled(False) # Enabled when stream starts

        layout.addWidget(form_widget)
        button_layout = QHBoxLayout()
        button_layout.addWidget(self.start_stop_button)
        button_layout.addWidget(self.record_button)
        layout.addLayout(button_layout)

        # --- Connect UI changes to service ---
        self.denoise_slider.valueChanged.connect(self.update_params)
        self.k_slider.valueChanged.connect(self.update_params)
        self.steps_slider.valueChanged.connect(self.update_params)
        self.anticlip_check.toggled.connect(self.update_params)
        
        # --- Connect level meters ---
        self.stream_service.input_level.connect(self.update_input_meter)
        self.stream_service.output_level.connect(self.update_output_meter)

        log.info("PageLive (UI) initialized.")
        
    def refresh_devices(self):
        """Updates the audio device dropdowns."""
        self.input_combo.clear()
        self.output_combo.clear()
        devices = sd.query_devices()
        
        pgf_input_idx = None
        pgf_output_idx = None
        
        for i, device in enumerate(devices):
            device_name = device.get('name', f'Device {i}')
            if device.get('max_input_channels', 0) > 0:
                self.input_combo.addItem(device_name, i)
                if 'pgf' in device_name.lower() or 'virtual' in device_name.lower():
                    pgf_input_idx = self.input_combo.count() - 1
            if device.get('max_output_channels', 0) > 0:
                self.output_combo.addItem(device_name, i)
                # Try to auto-select PGF Audio virtual device
                if 'pgf' in device_name.lower() or 'virtual' in device_name.lower():
                    pgf_output_idx = self.output_combo.count() - 1
        
        # Set default selections if found
        if pgf_input_idx is not None:
            self.input_combo.setCurrentIndex(pgf_input_idx)
        if pgf_output_idx is not None:
            self.output_combo.setCurrentIndex(pgf_output_idx)
        
    def update_params(self):
        """Send the UI slider values to the stream service."""
        k_val = self.k_slider.value() / 100.0
        steps_val = self.steps_slider.value()
        denoise_val = self.denoise_slider.value()
        anticlip_val = self.anticlip_check.isChecked()
        
        self.stream_service.update_filter_params(
            denoise_amount=denoise_val,
            enable_anti_clip=anticlip_val,
            steps=steps_val,
            k_value=k_val
        )
        
        # Save to config
        set_setting('LiveFilter', 'DenoiseAmount', str(denoise_val))
        set_setting('LiveFilter', 'EnableAntiClip', str(anticlip_val))

    def toggle_stream(self, checked):
        """Starts or stops the audio stream service."""
        if checked:
            try:
                in_idx = self.input_combo.currentData()
                out_idx = self.output_combo.currentData()
                self.stream_service.start(in_idx, out_idx)
                self.start_stop_button.setText("Stop Filter")
                self.record_button.setEnabled(True)
                log.info("Stream service started by UI.")
            except Exception as e:
                log.error(f"Failed to start stream: {e}")
                self.start_stop_button.setChecked(False)
        else:
            # If recording, stop it first
            if self.record_button.isChecked():
                self.record_button.setChecked(False)
                self.toggle_recording(False)
            
            self.stream_service.stop()
            self.start_stop_button.setText("Start Filter")
            self.record_button.setEnabled(False)
            log.info("Stream service stopped by UI.")
    
    def toggle_recording(self, checked: bool):
        """Starts or stops recording the processed audio."""
        if checked:
            # Define a filename for the recording
            recordings_dir = "recordings"
            os.makedirs(recordings_dir, exist_ok=True)
            timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            file_path = os.path.join(recordings_dir, f"PGF_Live_{timestamp}.wav")
            
            self.stream_service.start_recording(file_path)
            self.record_button.setText("Stop Recording")
            self.record_button.setStyleSheet("background-color: red; color: white;")
            log.info(f"Recording started. Saving to {file_path}")
        else:
            self.stream_service.stop_recording()
            self.record_button.setText("Start Recording")
            self.record_button.setStyleSheet("") # Reset style
            log.info("Recording stopped.")

    def update_input_meter(self, level: float):
        """Update input level meter."""
        # Convert RMS to dB (0.0-1.0 RMS -> -60 to 0 dB)
        if level > 0:
            db = 20 * (level ** 0.5) * 100  # Simplified mapping
            db = min(100, max(0, db))
        else:
            db = 0
        self.input_meter.setValue(int(db))
    
    def update_output_meter(self, level: float):
        """Update output level meter."""
        # Convert RMS to dB
        if level > 0:
            db = 20 * (level ** 0.5) * 100  # Simplified mapping
            db = min(100, max(0, db))
        else:
            db = 0
        self.output_meter.setValue(int(db))