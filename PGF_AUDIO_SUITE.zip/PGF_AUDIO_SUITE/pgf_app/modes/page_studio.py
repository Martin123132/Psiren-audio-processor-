from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QListWidget, \
                            QStackedWidget, QToolBar, QPushButton, QFileDialog, QSlider
from PyQt5.QtCore import Qt
from ..core.logger import log
from ..core.audio_loader import load_audio, save_audio
from ..core.playback_engine import PlaybackEngine
from ..ui.custom_widgets import WaveformEditor
from ..studio_panels.denoise_panel import DenoisePanel
from ..studio_panels.declip_panel import DeclipPanel
from ..studio_panels.declick_panel import DeclickPanel
from ..studio_panels.clarity_panel import ClarityPanel
from collections import deque
import os

class PageStudio(QWidget):
    """
    The UI page for the "Studio" (repair) mode.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.playback_engine = PlaybackEngine()

        # Undo/Redo stacks
        self.undo_stack = deque(maxlen=20) # Store previous audio states
        self.redo_stack = deque(maxlen=20)

        # --- Main Layout ---
        main_layout = QHBoxLayout(self)
        
        # --- 1. Left Panel (File/Module List) ---
        left_panel = QWidget()
        left_panel.setFixedWidth(200)
        left_layout = QVBoxLayout(left_panel)
        
        self.load_button = QPushButton("Load Audio File...")
        self.load_button.clicked.connect(self.load_file)
        left_layout.addWidget(self.load_button)
        
        self.batch_process_button = QPushButton("Process Folder...")
        self.batch_process_button.clicked.connect(self.batch_process_folder)
        left_layout.addWidget(self.batch_process_button)

        self.save_button = QPushButton("Save As...")
        self.save_button.clicked.connect(self.save_file)
        self.save_button.setEnabled(False)
        left_layout.addWidget(self.save_button)
        
        # --- Undo/Redo Buttons ---
        undo_redo_layout = QHBoxLayout()
        self.undo_button = QPushButton("Undo")
        self.undo_button.clicked.connect(self.undo)
        self.undo_button.setEnabled(False)
        self.redo_button = QPushButton("Redo")
        self.redo_button.clicked.connect(self.redo)
        self.redo_button.setEnabled(False)
        undo_redo_layout.addWidget(self.undo_button)
        undo_redo_layout.addWidget(self.redo_button)
        left_layout.addLayout(undo_redo_layout)

        self.preview_button = QPushButton("Enable Preview")
        self.preview_button.setCheckable(True)
        self.preview_button.setChecked(True)
        self.preview_button.clicked.connect(self.toggle_preview)
        left_layout.addWidget(self.preview_button)

        # List of available modules
        self.module_list = QListWidget()
        self.module_list.addItems(["Denoise", "De-Clip", "De-Click", "Clarity"])
        self.module_list.currentRowChanged.connect(self.switch_panel)
        left_layout.addWidget(self.module_list)

        # --- 2. Right Panel (Editor) ---
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        
        # --- 2a. Top (Waveform Editor) ---
        self.waveform_editor = WaveformEditor()
        right_layout.addWidget(self.waveform_editor, stretch=2)
        
        # --- 2b. Playback Controls ---
        playback_controls = QHBoxLayout()
        self.play_button = QPushButton("Play")
        self.play_button.clicked.connect(self.playback_engine.play)
        self.play_button.setEnabled(False)
        self.pause_button = QPushButton("Pause")
        self.pause_button.clicked.connect(self.playback_engine.pause)
        self.pause_button.setEnabled(False)
        self.stop_button = QPushButton("Stop")
        self.stop_button.clicked.connect(self.playback_engine.stop)
        self.stop_button.setEnabled(False)
        
        self.position_slider = QSlider(Qt.Orientation.Horizontal)
        self.position_slider.setEnabled(False)
        self.position_slider.sliderMoved.connect(self.on_seek)
        
        playback_controls.addWidget(self.play_button)
        playback_controls.addWidget(self.pause_button)
        playback_controls.addWidget(self.stop_button)
        playback_controls.addWidget(self.position_slider, stretch=1)
        right_layout.addLayout(playback_controls)

        # --- 2c. Bottom (Module Panels) ---
        self.panel_stack = QStackedWidget()
        self.panel_stack.setFixedHeight(250)
        right_layout.addWidget(self.panel_stack, stretch=1)

        # --- Create and add the panels ---
        self.denoise_panel = DenoisePanel()
        self.declip_panel = DeclipPanel()
        self.declick_panel = DeclickPanel()
        self.clarity_panel = ClarityPanel()
        
        self.panel_stack.addWidget(self.denoise_panel)
        self.panel_stack.addWidget(self.declip_panel)
        self.panel_stack.addWidget(self.declick_panel)
        self.panel_stack.addWidget(self.clarity_panel)
        
        main_layout.addWidget(left_panel)
        main_layout.addWidget(right_panel, stretch=1)

        # Wire all panels to live preview
        self.denoise_panel.params_changed.connect(
            lambda params: self.playback_engine.update_filter_preview(enabled=True, params=params)
        )
        self.declick_panel.params_changed.connect(
            lambda params: self.playback_engine.update_filter_preview(enabled=True, params=params)
        )
        self.clarity_panel.params_changed.connect(
            lambda params: self.playback_engine.update_filter_preview(enabled=True, params=params)
        )
        
        # Wire Declip panel signals
        self.declip_panel.detect_clips.connect(self.detect_clips)
        self.declip_panel.repair_clips.connect(self.repair_clips)
        
        # Wire playback position updates
        self.playback_engine.position_changed.connect(self.update_position)
        self.playback_engine.position_changed.connect(self.waveform_editor.update_playhead_position)

        # Track if audio has been modified
        self.is_modified = False

        log.info("PageStudio (UI) initialized.")

    def batch_process_folder(self):
        """Processes all audio files in a selected folder."""
        folder_path = QFileDialog.getExistingDirectory(self, "Select Folder to Process")
        if not folder_path:
            return

        output_path = os.path.join(folder_path, "processed")
        os.makedirs(output_path, exist_ok=True)
        log.info(f"Starting batch processing. Output will be saved to: {output_path}")

        current_item = self.module_list.currentItem()
        if not current_item:
            log.error("No processing module selected for batch processing.")
            # Optionally, show a QMessageBox to the user
            return
            
        module_name = current_item.text()
        log.info(f"Using module: {module_name}")

        # Get processing parameters from the current panel
        params = self._get_current_panel_params()
        if not params:
            log.error(f"Could not get parameters for module: {module_name}")
            return

        from ..core.engine_wrapper import PGFEngine
        engine = PGFEngine()
        engine.set_parameters(params['gamma'], params['k_value'], params['steps'])

        for filename in os.listdir(folder_path):
            if filename.lower().endswith(('.wav', '.flac')):
                input_file = os.path.join(folder_path, filename)
                output_file = os.path.join(output_path, filename)
                
                log.info(f"Processing {input_file}...")
                try:
                    data, sr = load_audio(input_file)
                    if data is not None:
                        # Process the entire file
                        engine.process(data)
                        save_audio(output_file, data, sr)
                        log.info(f"Saved processed file to {output_file}")
                except Exception as e:
                    log.error(f"Failed to process {input_file}: {e}")
        
        log.info("Batch processing complete.")

    def _get_current_panel_params(self):
        """Helper to get params from the currently active panel."""
        current_idx = self.module_list.currentRow()
        if current_idx == 0:
            return self.denoise_panel.get_params()
        elif current_idx == 1:
            return self.declip_panel.get_params()
        elif current_idx == 2:
            return self.declick_panel.get_params()
        elif current_idx == 3:
            return self.clarity_panel.get_params()
        return None

    def _push_undo_state(self, description: str):
        """Pushes the current audio data onto the undo stack."""
        if len(self.playback_engine.audio_data) > 0:
            log.debug(f"Pushing state to undo stack: {description}")
            self.undo_stack.append(self.playback_engine.audio_data.copy())
            self.redo_stack.clear() # Clear redo stack on new action
            self.update_undo_redo_buttons()

    def undo(self):
        """Reverts to the previous audio state."""
        if not self.undo_stack:
            return
        
        log.info("Performing Undo.")
        # Push current state to redo stack
        self.redo_stack.append(self.playback_engine.audio_data.copy())
        
        # Pop from undo stack and apply
        previous_state = self.undo_stack.pop()
        self._update_audio_state(previous_state, clear_clips=True)
        self.update_undo_redo_buttons()

    def redo(self):
        """Re-applies an undone audio state."""
        if not self.redo_stack:
            return

        log.info("Performing Redo.")
        # Push current state back to undo stack
        self.undo_stack.append(self.playback_engine.audio_data.copy())

        # Pop from redo stack and apply
        next_state = self.redo_stack.pop()
        self._update_audio_state(next_state, clear_clips=True)
        self.update_undo_redo_buttons()

    def _update_audio_state(self, new_data, clear_clips=False):
        """Helper to update all components with new audio data."""
        self.playback_engine.load_file(new_data, self.playback_engine.sample_rate)
        self.waveform_editor.set_waveform(new_data, self.playback_engine.sample_rate)
        if clear_clips:
            self.waveform_editor.clear_clip_markers()
        self.is_modified = True

    def update_undo_redo_buttons(self):
        """Enables/disables undo/redo buttons based on stack state."""
        self.undo_button.setEnabled(bool(self.undo_stack))
        self.redo_button.setEnabled(bool(self.redo_stack))

    def switch_panel(self, index: int):
        """Switches the visible module panel."""
        self.panel_stack.setCurrentIndex(index)
        # Enable preview for supported panels
        if index == 0:  # Denoise
            self.playback_engine.update_filter_preview(True, self.denoise_panel.get_params())
        elif index == 1:  # De-Clip (no preview, processes on demand)
            self.playback_engine.update_filter_preview(False, {})
        elif index == 2:  # De-Click
            self.declick_panel.on_params_changed()
        elif index == 3:  # Clarity
            self.clarity_panel.on_knob_changed(self.clarity_panel.clarity_knob.value())
        else:
            self.playback_engine.update_filter_preview(False, {})
        
    def load_file(self):
        """Opens a file dialog to load an audio file."""
        file_path, _ = QFileDialog.getOpenFileName(self, "Load Audio File", "", 
                                                   "Audio Files (*.wav *.flac *.mp3)")
        if file_path:
            log.info(f"Loading file: {file_path}")
            data, sr = load_audio(file_path)
            if data is not None:
                # Clear everything on new file load
                self.undo_stack.clear()
                self.redo_stack.clear()
                self.update_undo_redo_buttons()
                self.waveform_editor.clear_clip_markers()

                self.waveform_editor.set_waveform(data, sr)
                self.playback_engine.load_file(data, sr)
                # Enable playback controls
                self.play_button.setEnabled(True)
                self.pause_button.setEnabled(True)
                self.stop_button.setEnabled(True)
                self.position_slider.setEnabled(True)
                self.position_slider.setRange(0, len(data))
                self.save_button.setEnabled(True)
                log.info("File loaded successfully in Studio mode")
    
    def on_seek(self, position: int):
        """Called when user drags the position slider."""
        self.playback_engine.seek(position)
    
    def update_position(self, position: int):
        """Called when playback position changes."""
        # Update slider without triggering seek
        self.position_slider.blockSignals(True)
        self.position_slider.setValue(position)
        self.position_slider.blockSignals(False)
        # The playhead is updated via a direct connection now
    
    def toggle_preview(self, enabled: bool):
        """Toggle real-time preview on/off."""
        if enabled:
            self.preview_button.setText("Disable Preview")
            # Re-enable preview for current panel, if one is selected
            current_idx = self.module_list.currentRow()
            if current_idx >= 0:
                self.switch_panel(current_idx)
        else:
            self.preview_button.setText("Enable Preview")
            self.playback_engine.update_filter_preview(False, {})
        log.info(f"Preview {'enabled' if enabled else 'disabled'}")
    
    def save_file(self):
        """Save processed audio to file."""
        if len(self.playback_engine.audio_data) == 0:
            log.warning("No audio loaded to save")
            return
        
        file_path, _ = QFileDialog.getSaveFileName(self, "Save Audio File", "",
                                                   "WAV Files (*.wav);;FLAC Files (*.flac)")
        if file_path:
            # Get current panel and apply processing
            current_idx = self.module_list.currentRow()
            processed_data = self.playback_engine.audio_data.copy()
            
            # Apply the current panel's processing
            if current_idx == 0:  # Denoise
                params = self.denoise_panel.get_params()
                from ..core.engine_wrapper import PGFEngine
                engine = PGFEngine()
                engine.set_parameters(params['gamma'], params['k_value'], params['steps'])
                engine.process(processed_data)
            elif current_idx == 1:  # Declip - already processed via repair_clips
                pass  # Use current audio_data which has been repaired
            
            success = save_audio(file_path, processed_data, self.playback_engine.sample_rate)
            if success:
                log.info(f"Audio saved to {file_path}")
                self.is_modified = False
    
    def detect_clips(self):
        """Detect clipped samples in the loaded audio."""
        if len(self.playback_engine.audio_data) == 0:
            log.warning("No audio loaded")
            return
        
        # Detect clipped samples using numpy
        import numpy as np
        clipped_indices = np.nonzero(np.abs(self.playback_engine.audio_data) >= 0.98)[0]
        
        log.info(f"Detected {len(clipped_indices)} clipped samples")
        
        # Send markers to the waveform editor
        self.waveform_editor.set_clip_markers(clipped_indices)

        if len(clipped_indices) > 0:
            log.info(f"First clip at sample {clipped_indices[0]} ({clipped_indices[0]/self.playback_engine.sample_rate:.3f}s)")
            log.info(f"Last clip at sample {clipped_indices[-1]} ({clipped_indices[-1]/self.playback_engine.sample_rate:.3f}s)")
        else:
            log.info("No clipping detected!")
    
    def repair_clips(self, params: dict):
        """Repair clipped samples using PGF algorithm."""
        if len(self.playback_engine.audio_data) == 0:
            log.warning("No audio loaded")
            return
        
        log.info("Repairing clipped audio...")
        
        from ..core.engine_wrapper import PGFEngine
        engine = PGFEngine()
        engine.set_parameters(params['gamma'], params['k_value'], params['steps'])
        
        # Process the audio in-place
        repaired = self.playback_engine.audio_data.copy()
        
        # Push current state to undo stack BEFORE modifying
        self._push_undo_state("Repair Clips")

        engine.process(repaired)
        
        # Update the playback engine with repaired audio
        self._update_audio_state(repaired, clear_clips=True)
        
        self.is_modified = True
        log.info("Audio repair complete!")