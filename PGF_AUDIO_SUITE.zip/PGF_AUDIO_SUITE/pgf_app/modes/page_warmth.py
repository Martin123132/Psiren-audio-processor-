from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QDial, QLabel, QSlider, QPushButton, QFileDialog
from PyQt5.QtCore import Qt
from ..core.logger import setup_logging
from ..core.playback_engine import PlaybackEngine
from ..core.engine_wrapper import PGFEngine
from ..core.audio_loader import load_audio, save_audio
import numpy as np

log = setup_logging()
class PageWarmth(QWidget):
    """
    The UI page for the "Warmth" (Saturation) mode.
    This provides a "plugin-like" interface inside your app.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # This page will use its own engine/playback
        # (or share one from the main window)
        self.playback_engine = PlaybackEngine()
        
        # --- UI Layout ---
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # File controls
        file_controls = QHBoxLayout()
        self.load_button = QPushButton("Load Audio File")
        self.load_button.clicked.connect(self.load_file)
        self.play_button = QPushButton("Play")
        self.play_button.clicked.connect(self.playback_engine.play)
        self.play_button.setEnabled(False)
        self.pause_button = QPushButton("Pause")
        self.pause_button.clicked.connect(self.playback_engine.pause)
        self.pause_button.setEnabled(False)
        self.stop_button = QPushButton("Stop")
        self.stop_button.clicked.connect(self.playback_engine.stop)
        self.stop_button.setEnabled(False)
        
        self.save_button = QPushButton("Save As...")
        self.save_button.clicked.connect(self.save_file)
        self.save_button.setEnabled(False) # Disabled until file is loaded

        file_controls.addWidget(self.load_button)
        file_controls.addWidget(self.play_button)
        file_controls.addWidget(self.pause_button)
        file_controls.addWidget(self.stop_button)
        file_controls.addWidget(self.save_button)
        file_controls.addStretch()
        layout.addLayout(file_controls)
        
        self.drive_knob = QDial()
        self.drive_knob.setRange(0, 100)
        self.drive_knob.setValue(0)
        self.drive_knob.setNotchesVisible(True)
        self.drive_knob.setFixedSize(200, 200)
        
        self.drive_label = QLabel("DRIVE: 0%")
        self.drive_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # Quality (Steps)
        self.steps_slider = QSlider(Qt.Orientation.Horizontal)
        self.steps_slider.setRange(1, 50)
        self.steps_slider.setValue(8)
        self.steps_label = QLabel("QUALITY (Steps): 8")
        self.steps_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        layout.addWidget(self.drive_knob)
        layout.addWidget(self.drive_label)
        layout.addWidget(self.steps_slider)
        layout.addWidget(self.steps_label)
        
        # --- Connect Signals ---
        self.drive_knob.valueChanged.connect(self.update_filter)
        self.steps_slider.valueChanged.connect(self.on_steps_changed)

        log.info("PageWarmth (UI) initialized.")

    def load_file(self):
        """Opens a file dialog to load an audio file."""
        file_path, _ = QFileDialog.getOpenFileName(self, "Load Audio File", "", 
                                                   "Audio Files (*.wav *.flac *.mp3)")
        if file_path:
            log.info(f"Loading file: {file_path}")
            data, sr = load_audio(file_path)
            if data is not None:
                self.playback_engine.load_file(data, sr)
                # Enable playback and save controls
                self.play_button.setEnabled(True)
                self.pause_button.setEnabled(True)
                self.stop_button.setEnabled(True)
                self.save_button.setEnabled(True)
                # Apply current warmth settings
                self.update_filter(self.drive_knob.value())
                log.info("File loaded successfully in Warmth mode")

    def save_file(self):
        """Saves the processed audio to a new file."""
        if self.playback_engine.audio_data is None:
            log.warning("No audio data to save in Warmth mode.")
            return

        file_path, _ = QFileDialog.getSaveFileName(self, "Save Processed Audio", "",
                                                   "WAV Files (*.wav);;FLAC Files (*.flac)")

        if file_path:
            log.info(f"Saving processed audio to: {file_path}")
            
            # Get original data and sample rate
            original_data = self.playback_engine.audio_data
            sr = self.playback_engine.sample_rate
            
            # Get current processing parameters
            drive_float = self.drive_knob.value() / 100.0
            gamma = 0.1 + (drive_float * 0.5)
            k_value = 0.5 - (drive_float * 0.45)
            steps = int(self.steps_slider.value())

            # --- Full Processing for Saving ---
            # We create a new engine instance to process the whole file
            engine = PGFEngine()
            engine.set_parameters(gamma, k_value, steps)
            
            # The "warmth" effect is essentially a pre-gain followed by the PGF
            # The pre-gain drives the signal into the non-linear part of the filter
            pre_gain_linear = 10 ** ((drive_float * 24) / 20.0)
            
            processed_data = np.copy(original_data).astype(np.float32) * pre_gain_linear
            
            # Process with PGF
            processed_data = engine.process(processed_data)
            
            # Normalize to prevent clipping and match perceived loudness
            max_val = np.max(np.abs(processed_data))
            if max_val > 0:
                processed_data /= max_val
            
            # Save the processed data
            save_audio(file_path, processed_data, sr)
            log.info(f"Successfully saved file to {file_path}")

    def update_filter(self, value):
        """Called when the knob is turned."""
        self.drive_label.setText(f"DRIVE: {value}%")
        
        # --- Translate "Drive" to PGF parameters ---
        # This is the "sound design" part.
        drive_float = value / 100.0
        
        # The "warmth" effect is essentially a pre-gain followed by the PGF
        # The pre-gain drives the signal into the non-linear part of the filter
        pre_gain_linear = 10 ** ((drive_float * 24) / 20.0)

        # As drive goes up, input gain goes up (conceptually)
        # and K goes down (more sensitive clipping)
        # and Gamma goes up (more smoothing of the clip)
        
        gamma = 0.1 + (drive_float * 0.5)
        k_value = 0.5 - (drive_float * 0.45)
        # Steps from UI
        steps = int(self.steps_slider.value())
        
        # Update the playback engine's filter
        params = {
            'gamma': gamma, 
            'k_value': k_value, 
            'steps': steps,
            'pre_gain_linear': pre_gain_linear # Pass gain to playback
        }
        self.playback_engine.update_filter_preview(enabled=True, params=params)
        
        log.debug(f"Warmth params updated: G={gamma:.2f}, K={k_value:.2f}, N={steps}, PreGain={pre_gain_linear:.2f}")

    def on_steps_changed(self, value: int):
        self.steps_label.setText(f"QUALITY (Steps): {value}")
        # Re-apply with current drive setting
        self.update_filter(self.drive_knob.value())