from PyQt5.QtWidgets import QGraphicsView, QGraphicsScene, QWidget, QVBoxLayout, QGraphicsLineItem
from PyQt5.QtGui import QPainter, QPen, QBrush, QColor, QPixmap, QWheelEvent, QMouseEvent
from PyQt5.QtCore import Qt, QRectF
from typing import Optional
import numpy as np
from ..core.logger import log

class WaveformEditor(QGraphicsView):
    """
    A custom widget to display an audio waveform.
    This is a simplified example; a real one would be much more complex,
    handling zooming, panning, and spectrograms.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self._scene = QGraphicsScene(self)
        self.setScene(self._scene)
        
        # Optimize rendering
        self.setRenderHint(QPainter.Antialiasing, True)
        self.setViewportUpdateMode(QGraphicsView.BoundingRectViewportUpdate)
        self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag) # Enable panning
        
        self.audio_data = np.array([], dtype=np.float32)
        self.pixmap = None
        self.clip_indices = np.array([], dtype=np.int64)

        self.setBackgroundBrush(QBrush(QColor(25, 25, 25))) # Dark background

        # Add a playhead line
        self.playhead = QGraphicsLineItem(0, 0, 0, 300) # x1, y1, x2, y2
        self.playhead.setPen(QPen(QColor(255, 100, 100), 2)) # Red, thicker pen
        self.playhead.setZValue(10) # Ensure it's drawn on top
        self._scene.addItem(self.playhead)
        self.playhead.hide()

    def wheelEvent(self, event: Optional[QWheelEvent]):
        """Handle mouse wheel for zooming."""
        if not event:
            return
        zoom_in_factor = 1.15
        zoom_out_factor = 1 / zoom_in_factor

        # Zoom
        if event.angleDelta().y() > 0:
            self.scale(zoom_in_factor, zoom_in_factor)
        else:
            self.scale(zoom_out_factor, zoom_out_factor)
        event.accept()

    def set_clip_markers(self, indices: np.ndarray):
        """Stores the indices of detected clips and redraws the waveform."""
        self.clip_indices = indices
        log.info(f"Set {len(indices)} clip markers for display.")
        self.update_waveform_pixmap() # Redraw with markers

    def clear_clip_markers(self):
        """Clears any existing clip markers and redraws."""
        if len(self.clip_indices) > 0:
            self.clip_indices = np.array([], dtype=np.int64)
            log.info("Cleared clip markers.")
            self.update_waveform_pixmap() # Redraw without markers

    def set_waveform(self, data: np.ndarray, sample_rate: int):
        """Loads new audio data and triggers a redraw."""
        self.audio_data = data
        self.sample_rate = sample_rate
        log.info(f"Waveform editor: loaded {len(data)} samples.")
        
        # In a real app, you'd generate the waveform path here
        # and create a QPixmap or QPainterPath for efficient drawing.
        # This is a placeholder.
        self.update_waveform_pixmap()
        self.playhead.setY(self._scene.sceneRect().top())
        self.playhead.setLine(0, 0, 0, self._scene.sceneRect().height())
        self.playhead.show()
        self.fitInView(self._scene.sceneRect(), Qt.AspectRatioMode.KeepAspectRatio)

    def update_waveform_pixmap(self):
        """
        Generates the visual waveform.
        (This is a simplified, inefficient version for clarity).
        """
        if self.audio_data.size == 0:
            return
            
        w, h = 2000, 300 # Fixed size pixmap (a real one would be dynamic)
        pix = QPixmap(w, h)
        pix.fill(QColor(0, 0, 0, 0))
        
        painter = QPainter(pix)
        pen = QPen(QColor(100, 200, 255)) # Waveform color
        pen.setWidth(1)
        painter.setPen(pen)

        # Downsample the data to fit the width
        step = len(self.audio_data) // w
        if step == 0: step = 1
        
        samples = self.audio_data[::step]
        
        for i, sample in enumerate(samples[:w]):
            y_pos = (1 - sample) * (h / 2) # sample is -1 to 1
            painter.drawLine(i, int(y_pos), i, int(y_pos) + 1)
            
        # --- Draw Clip Markers ---
        if len(self.clip_indices) > 0:
            marker_pen = QPen(QColor(255, 0, 0, 150)) # Semi-transparent red
            marker_pen.setWidth(1)
            painter.setPen(marker_pen)
            
            # Convert sample indices to x-coordinates
            marker_xs = (self.clip_indices / len(self.audio_data)) * w
            
            # To avoid overdrawing, group nearby markers
            # For simplicity here, we'll just draw them all.
            for x_pos in marker_xs:
                painter.drawLine(int(x_pos), 0, int(x_pos), h)

        painter.end()
        
        self._scene.clear()
        self._scene.addPixmap(pix)
        self.setSceneRect(0, 0, w, h)
        # Don't fitInView here, let the user control zoom
        log.debug("Waveform pixmap updated.")

        # Re-add the playhead after clearing the scene
        self._scene.addItem(self.playhead)

    def update_playhead_position(self, current_sample: int):
        """Moves the playhead to the specified sample position."""
        if self.audio_data.size == 0:
            return
        
        # Convert sample index to x-coordinate in the scene
        scene_width = self._scene.sceneRect().width()
        x_pos = (current_sample / len(self.audio_data)) * scene_width
        
        self.playhead.setX(x_pos)

    def resizeEvent(self, event):
        """Fit the waveform to the view when resized."""
        super().resizeEvent(event)
        if self.audio_data.size > 0:
            # Only fit if the scene is not manually zoomed/panned
            if self.transform().isIdentity():
                 self.fitInView(self._scene.sceneRect(), Qt.AspectRatioMode.KeepAspectRatio)