from PyQt5.QtWidgets import QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, \
                            QPushButton, QStackedWidget, QShortcut
from PyQt5.QtCore import QSize
from PyQt5.QtGui import QKeySequence
from ..core.logger import log
from ..modes.page_live import PageLive
from ..modes.page_studio import PageStudio
from ..modes.page_warmth import PageWarmth

class MainWindow(QMainWindow):
    """
    The main application shell. It holds the mode-switching
    UI and the QStackedWidget that contains each mode's page.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("PGF Audio Suite")
        self.setMinimumSize(1024, 768)

        # --- Main Layout ---
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout(main_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # --- 1. Mode Switcher (Top Bar) ---
        mode_bar_widget = QWidget()
        mode_bar_widget.setStyleSheet("background-color: #2a2a2a;")
        mode_bar_widget.setFixedHeight(50)
        mode_bar_layout = QHBoxLayout(mode_bar_widget)
        mode_bar_layout.setContentsMargins(10, 0, 10, 0)
        
        self.live_button = QPushButton("Live Filter")
        self.studio_button = QPushButton("Studio")
        self.warmth_button = QPushButton("Warmth")
        
        self.live_button.setCheckable(True)
        self.studio_button.setCheckable(True)
        self.warmth_button.setCheckable(True)

        mode_bar_layout.addWidget(self.live_button)
        mode_bar_layout.addWidget(self.studio_button)
        mode_bar_layout.addWidget(self.warmth_button)
        mode_bar_layout.addStretch()

        # --- 2. Page Container (Stacked Widget) ---
        self.page_stack = QStackedWidget()
        
        # --- 3. Create and add the pages ---
        self.page_live = PageLive()
        self.page_studio = PageStudio()
        self.page_warmth = PageWarmth()
        
        self.page_stack.addWidget(self.page_live)
        self.page_stack.addWidget(self.page_studio)
        self.page_stack.addWidget(self.page_warmth)
        
        main_layout.addWidget(mode_bar_widget)
        main_layout.addWidget(self.page_stack)

        # --- Connect Signals ---
        self.live_button.clicked.connect(lambda: self.switch_mode(0))
        self.studio_button.clicked.connect(lambda: self.switch_mode(1))
        self.warmth_button.clicked.connect(lambda: self.switch_mode(2))
        
        # --- Set Initial Mode ---
        self.switch_mode(0) # Default to Live mode
        
        # --- Setup Global Shortcuts ---
        self.setup_shortcuts()
        log.info("MainWindow initialized.")

    def setup_shortcuts(self):
        """Sets up global keyboard shortcuts."""
        # Play/Pause
        play_pause_shortcut = QShortcut(QKeySequence("Space"), self)
        play_pause_shortcut.activated.connect(self.toggle_play_pause)

        # Save
        save_shortcut = QShortcut(QKeySequence.StandardKey.Save, self) # Ctrl+S
        save_shortcut.activated.connect(self.save_active_file)

        # Undo
        undo_shortcut = QShortcut(QKeySequence.StandardKey.Undo, self) # Ctrl+Z
        undo_shortcut.activated.connect(self.undo_active)

        # Redo
        redo_shortcut = QShortcut(QKeySequence.StandardKey.Redo, self) # Ctrl+Y
        redo_shortcut.activated.connect(self.redo_active)
        log.info("Global shortcuts configured.")

    def get_current_page(self) -> QWidget:
        """Returns the currently visible page widget."""
        return self.page_stack.currentWidget()

    def toggle_play_pause(self):
        """Toggles play/pause on the active page's playback engine."""
        page = self.get_current_page()
        if hasattr(page, 'playback_engine') and page.play_button.isEnabled():
            if page.playback_engine.is_playing:
                page.playback_engine.pause()
                log.debug("Shortcut: Paused playback.")
            else:
                page.playback_engine.play()
                log.debug("Shortcut: Started playback.")

    def save_active_file(self):
        """Triggers the save function on the active page."""
        page = self.get_current_page()
        if hasattr(page, 'save_file') and page.save_button.isEnabled():
            page.save_file()
            log.debug("Shortcut: Triggered save.")

    def undo_active(self):
        """Triggers the undo function on the active page (if available)."""
        page = self.get_current_page()
        # Check for the specific page type and if the button is enabled
        if isinstance(page, PageStudio) and page.undo_button.isEnabled():
            page.undo()
            log.debug("Shortcut: Triggered undo.")

    def redo_active(self):
        """Triggers the redo function on the active page (if available)."""
        page = self.get_current_page()
        if isinstance(page, PageStudio) and page.redo_button.isEnabled():
            page.redo()
            log.debug("Shortcut: Triggered redo.")

    def switch_mode(self, index: int):
        """Switches the visible page in the QStackedWidget."""
        self.page_stack.setCurrentIndex(index)
        
        # Update button styles
        self.live_button.setChecked(index == 0)
        self.studio_button.setChecked(index == 1)
        self.warmth_button.setChecked(index == 2)
        
        log.info(f"Switched to mode index {index}.")