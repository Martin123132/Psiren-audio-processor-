import sounddevice as sd
import numpy as np
from typing import Optional
from .logger import log
from .engine_wrapper import PGFEngine
from PyQt5.QtCore import QObject, pyqtSignal
import soundfile as sf

class AudioStreamService(QObject):
    """
    Manages the real-time audio stream for the "Live" mode.
    
    This object runs the main audio callback, which:
    1. Reads a chunk from the microphone.
    2. Runs the PGF filter on it.
    3. Sends the clean chunk to the virtual output.
    """
    # Signals to send data to the UI for visualization
    input_level = pyqtSignal(float)
    output_level = pyqtSignal(float)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.pgf_engine = PGFEngine()
        self.stream = None
        self.is_running = False
        
        # Filter settings
        self.gamma = 0.1
        self.steps = 3
        self.k_value = 0.1
        self.anti_clip_enabled = True

        # Recording state
        self.is_recording = False
        self.recording_file = None
        self.sample_rate = 48000 # Fixed for live mode

    def _audio_callback(self, indata, outdata, frames, time, status):
        """This is the core "assembly line" running in a background thread."""
        if status:
            log.warning(f"Audio stream status: {status}")
        
        try:
            # 1. Calculate input level for UI
            input_rms = np.sqrt(np.mean(indata**2))
            self.input_level.emit(float(input_rms))
            
            # 2. Process the audio
            # We must process a *copy*
            clean_data = indata.copy()
            self.pgf_engine.process(clean_data)
            
            # 3. Calculate output level for UI
            output_rms = np.sqrt(np.mean(clean_data**2))
            self.output_level.emit(float(output_rms))
            
            # 4. Send to output
            outdata[:] = clean_data

            # 5. Write to file if recording
            if self.is_recording and self.recording_file:
                self.recording_file.write(clean_data)
            
        except Exception as e:
            log.error(f"Error in audio callback: {e}")
            outdata.fill(0) # Mute output on error

    def start(self, input_device_idx, output_device_idx):
        if self.is_running:
            self.stop()
            
        log.info(f"Starting audio stream. Input: {input_device_idx}, Output: {output_device_idx}")
        self.pgf_engine.set_parameters(self.gamma, self.k_value, self.steps)
        
        try:
            self.stream = sd.Stream(
                samplerate=self.sample_rate,
                blocksize=480,    # 10ms chunks
                device=(input_device_idx, output_device_idx),
                channels=1,
                dtype='float32',
                callback=self._audio_callback
            )
            self.stream.start()
            self.is_running = True
        except Exception as e:
            log.error(f"Failed to start audio stream: {e}")

    def stop(self):
        if self.is_recording:
            self.stop_recording()
        if self.stream:
            self.stream.stop()
            self.stream.close()
            self.stream = None
        self.is_running = False
        log.info("Audio stream stopped.")

    def start_recording(self, file_path: str):
        """Opens a file and sets the recording flag."""
        if self.is_recording:
            return
        try:
            self.recording_file = sf.SoundFile(file_path, mode='w', samplerate=self.sample_rate, channels=1)
            self.is_recording = True
            log.info(f"Recording to {file_path} started.")
        except Exception as e:
            log.error(f"Could not start recording to {file_path}: {e}")
            self.recording_file = None

    def stop_recording(self):
        """Closes the file and resets the recording flag."""
        if not self.is_recording:
            return
        self.is_recording = False
        if self.recording_file:
            self.recording_file.close()
            self.recording_file = None
            log.info("Recording file closed.")

    def update_filter_params(self, denoise_amount: int, enable_anti_clip: bool, steps: Optional[int] = None, k_value: Optional[float] = None):
        """Called by the UI to update the filter in real-time."""
        self.gamma = float(denoise_amount) / 100.0  # (e.g., 30 -> 0.3)
        self.anti_clip_enabled = enable_anti_clip
        if k_value is not None:
            self.k_value = float(k_value)
        if steps is not None:
            self.steps = int(steps)

        self.pgf_engine.set_parameters(self.gamma, self.k_value, self.steps)