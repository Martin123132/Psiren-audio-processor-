import sounddevice as sd
import numpy as np
from .logger import log
from .engine_wrapper import PGFEngine
from PyQt5.QtCore import QObject, pyqtSignal

class PlaybackEngine(QObject):
    """
    Manages loading, playing, and preview-filtering
    an audio file for the "Studio" mode.
    """
    # Signal to update the timeline slider in the UI
    position_changed = pyqtSignal(int) # (current_sample)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.pgf_engine = PGFEngine()
        self.stream = None
        self.is_playing = False
        
        # Audio data
        self.audio_data = np.array([], dtype=np.float32)
        self.sample_rate = 44100
        self.current_sample = 0
        
        # Filter settings
        self.filter_enabled = False
        self.filter_params = {'gamma': 0.1, 'k_value': 0.1, 'steps': 5}
        
    def load_file(self, data: np.ndarray, sample_rate: int):
        """Loads audio data from audio_loader."""
        self.stop()
        self.audio_data = data
        self.sample_rate = sample_rate
        self.current_sample = 0
        log.info(f"Playback engine loaded {len(data)} samples.")
        
    def _playback_callback(self, outdata, frames, time, status):
        """The 'assembly line' for file playback."""
        if status:
            log.warning(f"Playback stream status: {status}")
            
        # Get the chunk of audio to play
        start = self.current_sample
        end = start + frames
        
        if end > len(self.audio_data):
            # End of file
            chunk = self.audio_data[start:]
            outdata[:len(chunk)] = 0 # Write the last bit
            outdata[len(chunk):] = 0 # Fill rest with silence
            self.stop()
            raise sd.CallbackStop
        else:
            chunk = self.audio_data[start:end]

        # Apply the PGF filter *if* preview is on
        if self.filter_enabled:
            # Must use a copy
            chunk = chunk.copy()
            # Special handling for warmth pre-gain
            if 'pre_gain_linear' in self.filter_params:
                chunk *= self.filter_params['pre_gain_linear']

            chunk = self.pgf_engine.process(chunk)

            # Basic normalization to prevent harsh clipping on preview
            max_val = np.max(np.abs(chunk))
            if max_val > 0.99:
                 chunk /= (max_val * 1.01)

        outdata[:] = chunk.reshape(-1, 1) # Ensure correct shape
        
        self.current_sample = end
        self.position_changed.emit(self.current_sample)

    def play(self):
        if self.is_playing or len(self.audio_data) == 0:
            return
            
        log.info("Starting playback...")
        self.stream = sd.OutputStream(
            samplerate=self.sample_rate,
            blocksize=2048, # Larger buffer for playback
            channels=1,
            dtype='float32',
            callback=self._playback_callback
        )
        self.stream.start()
        self.is_playing = True

    def pause(self):
        if self.stream:
            self.stream.stop()
            self.stream.close()
            self.stream = None
        self.is_playing = False
        log.info(f"Playback paused at sample {self.current_sample}.")

    def stop(self):
        self.pause()
        self.current_sample = 0
        self.position_changed.emit(0)
        log.info("Playback stopped and reset.")
        
    def seek(self, sample_position: int):
        """Jumps to a specific sample in the audio."""
        self.current_sample = max(0, min(sample_position, len(self.audio_data)))
        
    def update_filter_preview(self, enabled: bool, params: dict):
        """Called by the UI to turn on/off the live preview."""
        self.filter_enabled = enabled
        if params:
            self.filter_params.update(params)
            self.pgf_engine.set_parameters(
                self.filter_params.get('gamma', 0.1),
                self.filter_params.get('k_value', 0.1),
                self.filter_params.get('steps', 5)
            )