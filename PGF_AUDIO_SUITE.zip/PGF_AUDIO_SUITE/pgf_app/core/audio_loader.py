import soundfile as sf
import numpy as np
import typing
from .logger import log
from PyQt5.QtWidgets import QMessageBox

def load_audio(file_path: str) -> tuple[np.ndarray | None, int]:
    """
    Loads an audio file into a NumPy array (float32).
    """
    try:
        audio_data, sample_rate = typing.cast(tuple[np.ndarray, int], sf.read(file_path, dtype='float32'))
        log.info(f"Loaded audio file: {file_path}")
        
        # Ensure it's mono for simplicity
        # Ensure it's mono for simplicity
        if audio_data.ndim > 1:
            log.warning("Audio is stereo, converting to mono.")
            audio_data = np.mean(audio_data, axis=1)
            
        return audio_data, sample_rate
        
    except sf.LibsndfileError as e:
        log.error(f"Libsndfile error loading {file_path}: {e}")
        QMessageBox.critical(None, "Error Loading File",
                             f"Could not load audio file: {file_path}\n\n"
                             f"Reason: {e}\n\n"
                             "Please ensure the file is a standard WAV or FLAC format. "
                             "MP3 support is not available by default.")
        return None, 0
    except Exception as e:
        log.error(f"Failed to load audio file {file_path}: {e}")
        QMessageBox.critical(None, "Error Loading File",
                             f"An unexpected error occurred while loading the file: {file_path}\n\n"
                             f"Details: {e}")
        return None, 0

def save_audio(file_path: str, data: np.ndarray, sample_rate: int):
    """
    Saves a NumPy array (float32) to an audio file.
    """
    try:
        # soundfile automatically chooses format by extension (e.g., .wav, .flac)
        sf.write(file_path, data, sample_rate, subtype='PCM_24')
        log.info(f"Saved audio file: {file_path}")
        return True
    except Exception as e:
        log.error(f"Failed to save audio file {file_path}: {e}")
        QMessageBox.critical(None, "Error Saving File",
                             f"Could not save audio file: {file_path}\n\n"
                             f"Details: {e}")
        return False