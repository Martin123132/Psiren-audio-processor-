import configparser
import os

# --- Constants ---
# Use an OS-agnostic AppData directory
APP_DATA_DIR = os.path.join(
    os.environ.get('APPDATA') or os.environ.get('HOME') or os.path.expanduser('~'),
    "PGF_Audio"
)
CONFIG_FILE = os.path.join(APP_DATA_DIR, "settings.ini")

# Define the default structure
DEFAULT_CONFIG = {
    'General': {
        'LastMode': 'Live',
    },
    'LiveFilter': {
        'InputDevice': 'Default',
        'OutputDevice': 'Default',
        'DenoiseAmount': '30',
        'EnableAntiClip': 'True'
    },
    'Studio': {
        'LastProjectPath': ''
    },
    'Performance': {
        'GpuDevice': 'Auto'
    }
}

# --- Create the config parser instance ---
config = configparser.ConfigParser()

def load_config():
    """
    Loads the config.ini file. If it doesn't exist,
    it creates it with the default values.
    """
    if not os.path.exists(APP_DATA_DIR):
        os.makedirs(APP_DATA_DIR)

    if not os.path.exists(CONFIG_FILE):
        config.read_dict(DEFAULT_CONFIG)
        save_config()
    else:
        config.read(CONFIG_FILE)
    
    # Ensure all default sections and keys exist
    for section, keys in DEFAULT_CONFIG.items():
        if not config.has_section(section):
            config.add_section(section)
        for key, default_value in keys.items():
            if not config.has_option(section, key):
                config.set(section, key, default_value)
    
    print(f"Configuration loaded from {CONFIG_FILE}")

def save_config():
    """Saves the current config state to the file."""
    try:
        with open(CONFIG_FILE, 'w') as configfile:
            config.write(configfile)
    except Exception as e:
        print(f"Error saving config file: {e}")

# --- Public Helper Functions ---

def get_setting(section, key, is_bool=False, is_int=False):
    """Gets a specific setting value, with type casting."""
    if not config.sections():
        load_config()
        
    if is_bool:
        return config.getboolean(section, key)
    if is_int:
        return config.getint(section, key)
    return config.get(section, key)

def set_setting(section, key, value):
    """Sets a specific setting value and saves the file."""
    if not config.sections():
        load_config()
        
    config.set(section, key, str(value))
    save_config()

# --- Initial Load ---
# Load the config as soon as this file is imported.
load_config()