import ctypes
import numpy as np
import os
import sys

# Define a pointer type for a float array
FLOAT_POINTER = np.ctypeslib.ndpointer(dtype=np.float32, flags='C_CONTIGUOUS')

class PGFEngine:
    """
    A Python wrapper for the C++ PGF Engine library.
    
    This class handles loading the library, managing the C++ object
    handle, and converting Python types to C-types.
    """
    
    def __init__(self):
        """Loads the library and creates a new PGF_DSP handle."""
        self.lib = self._load_library()
        
        # --- 1. Define C function prototypes ---
        # (Must match PGF_Engine_API.h)
        
        # void* pgf_create_handle();
        self.lib.pgf_create_handle.restype = ctypes.c_void_p
        
        # void pgf_destroy_handle(void* handle);
        self.lib.pgf_destroy_handle.argtypes = [ctypes.c_void_p]
        
        # void pgf_set_parameters(void* handle, float gamma, float K, int steps);
        self.lib.pgf_set_parameters.argtypes = [
            ctypes.c_void_p,
            ctypes.c_float,
            ctypes.c_float,
            ctypes.c_int
        ]
        
        # void pgf_process_inplace(void* handle, float* buffer, int num_samples);
        self.lib.pgf_process_inplace.argtypes = [
            ctypes.c_void_p,
            FLOAT_POINTER,
            ctypes.c_int
        ]

        # --- 2. Create the C++ object ---
        self.handle = self.lib.pgf_create_handle()
        if not self.handle:
            raise RuntimeError("Failed to create PGF_DSP handle. C++ engine error.")

    def _load_library(self):
        """Finds and loads the compiled C++ shared library."""
        lib_name = 'pgf_engine.dll' if sys.platform == 'win32' else 'libpgf_engine.so'
        
        # Look in the same directory as this file (or bundled path)
        lib_path = os.path.join(os.path.dirname(__file__), '..', lib_name)
        
        if not os.path.exists(lib_path):
            raise FileNotFoundError(f"PGF Engine library not found at {lib_path}")
            
        try:
            return ctypes.CDLL(lib_path)
        except Exception as e:
            raise RuntimeError(f"Failed to load PGF Engine library: {e}")

    def set_parameters(self, gamma: float, k_value: float, steps: int):
        """Sets the filter parameters on the C++ engine."""
        self.lib.pgf_set_parameters(self.handle, gamma, k_value, steps)

    def process(self, audio_chunk: np.ndarray):
        """
        Processes a NumPy audio chunk in-place.
        The chunk MUST be float32 and C-contiguous.
        """
        if audio_chunk.dtype != np.float32:
            audio_chunk = audio_chunk.astype(np.float32)
            
        self.lib.pgf_process_inplace(
            self.handle,
            audio_chunk,
            audio_chunk.size # num_samples
        )
        return audio_chunk # Return the modified chunk

    def __del__(self):
        """Destructor to clean up the C++ object."""
        if hasattr(self, 'lib') and hasattr(self, 'handle'):
            self.lib.pgf_destroy_handle(self.handle)