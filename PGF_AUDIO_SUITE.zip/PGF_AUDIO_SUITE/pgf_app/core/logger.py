import logging
import os
from logging.handlers import RotatingFileHandler

# Get the AppData directory from config_loader
from .config_loader import APP_DATA_DIR

LOG_FILE = os.path.join(APP_DATA_DIR, "app.log")

def setup_logging():
    """
    Configures the root logger for the application.
    """
    # Create the logger
    logger = logging.getLogger("PGF_App")
    logger.setLevel(logging.DEBUG) # Capture all levels
    
    # Prevent duplicate handlers
    if logger.hasHandlers():
        return logger

    # --- File Handler (for errors/warnings) ---
    # Create a 10MB rotating log file
    file_handler = RotatingFileHandler(
        LOG_FILE,
        maxBytes=10*1024*1024, # 10 MB
        backupCount=3,
        encoding='utf-8'
    )
    file_handler.setLevel(logging.WARNING) # Only write warnings/errors to file
    file_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)

    # --- Console Handler (for dev/info) ---
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO) # Show INFO and above in console
    console_formatter = logging.Formatter('%(name)s - %(levelname)s - %(message)s')
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
    
    logger.info("----------------------------------")
    logger.info(f"Logger initialized. Log file at {LOG_FILE}")
    logger.info("----------------------------------")
    return logger

# --- Global Logger ---
# All other modules will import this 'log' object
log = setup_logging()